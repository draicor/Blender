"""``.unitypackage``（tar.gz）の走査・索引・オンデマンド展開。

tar.gz はランダムアクセスできないため、

1. ``scan()`` で 1 度ストリーム走査して GUID ごとの索引を作る
   （``pathname`` と ``asset.meta`` は小さいので常駐、``.mat`` / ``.prefab`` / ``.unity`` の実体もキャッシュ）
2. ``extract()`` で必要な GUID だけを 2 度目の走査で書き出す

という 2 パス構成にしている。
"""

from __future__ import annotations

import json
import os
import shutil
import tarfile
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath

__all__ = [
    "AssetEntry",
    "PackageError",
    "UnityPackage",
    "MODEL_EXTS",
    "TEXTURE_EXTS",
    "MATERIAL_EXTS",
    "PREFAB_EXTS",
    "SCENE_EXTS",
]

MODEL_EXTS = frozenset({".fbx", ".obj", ".dae", ".blend", ".gltf", ".glb", ".vrm"})  # .vrm は glTF バイナリ
TEXTURE_EXTS = frozenset(
    {".png", ".jpg", ".jpeg", ".tga", ".tif", ".tiff", ".bmp", ".exr", ".hdr", ".psd", ".webp"}
)
MATERIAL_EXTS = frozenset({".mat"})
PREFAB_EXTS = frozenset({".prefab"})
SCENE_EXTS = frozenset({".unity"})

# scan 時に実体をメモリへ載せておく拡張子。上限は ``_READ_ASSET_MAX_SIZE``。
# tar では ``asset`` が ``pathname`` より先に来るのが普通なので、種類の分からない ``asset`` はいったん読んで保持し、
# 同じ GUID の ``pathname`` で拡張子が分かった時点で残すか捨てるかを決める（保持するのは常に 1 件。#75）。
# ``pathname`` が続けて来ないパッケージでは、保持したものを ``_CACHE_MAX_SIZE`` 以下に限って残す（超えたものは read_asset で再走査）
_CACHE_EXTS = frozenset({".mat", ".prefab", ".unity", ".shader", ".shadergraph"})  # シェーダーは宣言の読み取り用（#118）
_CACHE_MAX_SIZE = 2 << 20  # 2 MiB
# メモリへ丸ごと読むメンバーの上限。tar ヘッダーのサイズで判定するので、gzip / sparse で
# 小さく見せた巨大メンバーでも展開前に弾ける。超えたものは警告して無視する
_METADATA_MAX_SIZE = 16 << 20  # pathname / asset.meta（通常は数 KB）
_READ_ASSET_MAX_SIZE = 64 << 20  # read_asset（.mat / .prefab のテキスト解析用）

ProgressFn = Callable[[float, str], None]


class PackageError(RuntimeError):
    """unitypackage として読めない場合に送出される。"""


@dataclass
class AssetEntry:
    guid: str
    pathname: str = ""
    has_asset: bool = False
    size: int = 0
    mtime: int = 0  # tar メンバーの更新時刻（展開済みファイルが同じものかの判定に使う）
    meta_text: str | None = None
    _cache: bytes | None = field(default=None, repr=False)

    @property
    def name(self) -> str:
        return PurePosixPath(self.pathname).name

    @property
    def ext(self) -> str:
        return PurePosixPath(self.pathname).suffix.lower()

    @property
    def kind(self) -> str:
        """``model`` / ``material`` / ``texture`` / ``prefab`` / ``scene`` / ``folder`` / ``other``"""
        if not self.has_asset:
            return "folder"
        ext = self.ext
        if ext in MODEL_EXTS:
            return "model"
        if ext in MATERIAL_EXTS:
            return "material"
        if ext in TEXTURE_EXTS:
            return "texture"
        if ext in PREFAB_EXTS:
            return "prefab"
        if ext in SCENE_EXTS:
            return "scene"
        return "other"


# 展開先に置く記録。展開したファイルの相対パス → 書き出した元の tar メンバーの GUID・サイズ・更新時刻（#72）
EXTRACT_RECORD_NAME = ".unitypackage_importer.json"
_RECORD_MAX_SIZE = 32 << 20


def _identity(entry: "AssetEntry") -> dict[str, object]:
    return {"guid": entry.guid, "size": entry.size, "mtime": entry.mtime}


def _load_record(dest_root: Path) -> dict[str, object]:
    """展開先の記録を読む。無い・壊れている・symlink なら空（どのファイルも使い回さない）。"""
    path = dest_root / EXTRACT_RECORD_NAME
    try:
        if path.is_symlink() or not path.is_file() or path.stat().st_size > _RECORD_MAX_SIZE:
            return {}
        data = json.loads(path.read_text("utf-8"))
    except (OSError, ValueError):
        return {}
    files = data.get("files") if isinstance(data, dict) else None
    return files if isinstance(files, dict) else {}


def _save_record(dest_root: Path, files: dict[str, object]) -> None:
    """記録を書く。symlink を通しては書かない。書けなくても展開は済んでいるので、次回に書き直すだけにする。"""
    path = dest_root / EXTRACT_RECORD_NAME
    temp = path.with_name(path.name + ".tmp")
    _reject_symlinks(dest_root, path)
    _reject_symlinks(dest_root, temp)
    data = json.dumps({"version": 1, "files": files}, ensure_ascii=False, sort_keys=True).encode("utf-8")
    try:
        dest_root.mkdir(parents=True, exist_ok=True)
        with _open_for_write(temp) as f:
            f.write(data)
        os.replace(temp, path)
    except OSError:
        pass


def _split_member(name: str) -> tuple[str, str] | None:
    """tar メンバー名を (guid, part) に分ける。想定外の形なら None。"""
    parts = [p for p in name.split("/") if p not in ("", ".")]
    if len(parts) != 2:
        return None
    guid, part = parts
    if len(guid) != 32 or any(c not in "0123456789abcdefABCDEF" for c in guid):
        return None
    return guid.lower(), part


# Windows で特別な意味を持つ文字・名前。展開先の OS に関係なく拒否する
# （Linux で展開したファイルを含む .blend を Windows で開く、といったケースがあるため）。
_INVALID_PATH_CHARS = frozenset('<>:"|?*') | frozenset(chr(c) for c in range(0x20)) | {"\x7f"}
_RESERVED_DEVICE_NAMES = frozenset(
    {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
)


def _check_path_component(part: str, pathname: str) -> None:
    """パスの 1 要素が展開先のファイル名として安全か確認する。"""
    if part in ("..", ""):
        raise PackageError(f"unsafe pathname in package: {pathname!r}")
    # コロンはドライブ文字（C:）と NTFS 代替データストリーム（name:stream）の両方を塞ぐ
    if any(c in _INVALID_PATH_CHARS for c in part):
        raise PackageError(f"pathname contains characters not allowed in file names: {pathname!r}")
    if part[-1] in (".", " "):
        raise PackageError(f"pathname component ends with a dot or space: {pathname!r}")
    # 予約デバイス名は拡張子が付いていても（CON.txt）デバイスとして解釈される
    if part.split(".", 1)[0].upper() in _RESERVED_DEVICE_NAMES:
        raise PackageError(f"pathname uses a reserved device name: {pathname!r}")


def safe_relative_path(pathname: str) -> PurePosixPath:
    """展開先に使える相対パスへ正規化する。

    ``..``、絶対パス、空要素に加え、Windows で展開先の外に出るか異常なファイルになる
    ドライブ文字・代替データストリーム（コロン）、制御文字、予約デバイス名、末尾のドット / 空白も拒否する。
    規則は OS に依らず同じ。
    """
    p = PurePosixPath(pathname.replace("\\", "/"))
    if p.is_absolute():
        raise PackageError(f"unsafe pathname in package: {pathname!r}")
    if not p.parts:
        raise PackageError("empty pathname in package")
    for part in p.parts:
        _check_path_component(part, pathname)
    return p


def _reject_symlinks(dest_root: Path, target: Path) -> None:
    """``dest_root`` から ``target`` までの各要素がシンボリックリンクでないことを確認する。

    展開先配下に既にリンクがあると（別パッケージの展開物や手作業で置かれたもの）、
    そこを経由して展開先の外へ書けてしまうため、リンクを見つけたら書かずに失敗させる。
    ``dest_root`` 自体はユーザーが選んだ場所なのでリンクでもよい。
    """
    current = dest_root
    for part in target.relative_to(dest_root).parts:
        current = current / part
        if current.is_symlink():
            raise PackageError(f"refusing to write through a symbolic link: {current}")


def _free_disk_space(dest_root: Path) -> int | None:
    """``dest_root``（未作成なら最も近い既存の親）のあるボリュームの空き容量。取れなければ None。"""
    probe = dest_root
    while not probe.exists():
        if probe.parent == probe:
            return None
        probe = probe.parent
    try:
        return shutil.disk_usage(probe).free
    except OSError:
        return None


def _open_for_write(target: Path):
    # 最終要素がリンクなら追従しない（対応 OS のみ）。Windows では O_BINARY が必要
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)
    return os.fdopen(os.open(target, flags, 0o644), "wb")


def _settle_cache(entry: AssetEntry) -> None:
    """scan で読んだ実体を残すか決める。拡張子が分かればそれで、分からなければ小さいものだけ残す（最後に決め直す）。"""
    if entry._cache is None:
        return
    if entry.pathname:
        if entry.ext not in _CACHE_EXTS:
            entry._cache = None
    elif len(entry._cache) > _CACHE_MAX_SIZE:
        entry._cache = None


def human_size(size: float) -> str:
    """バイト数を「12.3 MiB」のような表記にする（警告文とダイアログで使う）。"""
    for unit in ("B", "KiB", "MiB", "GiB"):
        if size < 1024 or unit == "GiB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GiB"


class UnityPackage:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.entries: dict[str, AssetEntry] = {}
        self.warnings: list[str] = []  # scan 中に無視したものの説明
        self._scanned = False

    # ------------------------------------------------------------------ scan
    def scan(self, progress: ProgressFn | None = None) -> dict[str, AssetEntry]:
        if self._scanned:
            return self.entries
        entries: dict[str, AssetEntry] = {}
        held: AssetEntry | None = None  # pathname より先に来た asset を読んで保持しているエントリー
        try:
            with tarfile.open(self.path, "r:*") as tar:
                for member in tar:
                    split = _split_member(member.name)
                    if split is None or not member.isfile():
                        continue
                    guid, part = split
                    entry = entries.get(guid)
                    if entry is None:
                        entry = entries[guid] = AssetEntry(guid)
                    if held is not None and held is not entry:
                        _settle_cache(held)  # 別の GUID に移った。pathname は後から来ないものとして扱う
                        held = None
                    if part in ("pathname", "asset.meta") and member.size > _METADATA_MAX_SIZE:
                        self.warnings.append(
                            f"ignored {member.name}: {member.size} bytes exceeds the {_METADATA_MAX_SIZE} byte limit"
                        )
                    elif part == "pathname":
                        text = tar.extractfile(member).read().decode("utf-8", "replace")
                        entry.pathname = text.splitlines()[0].strip() if text.strip() else ""
                        _settle_cache(entry)
                        held = None
                    elif part == "asset.meta":
                        entry.meta_text = tar.extractfile(member).read().decode("utf-8", "replace")
                    elif part == "asset":
                        entry.has_asset = True
                        entry.size = member.size
                        entry.mtime = int(member.mtime)
                        known = bool(entry.pathname)
                        if member.size <= _READ_ASSET_MAX_SIZE and (not known or entry.ext in _CACHE_EXTS):
                            entry._cache = tar.extractfile(member).read()
                            if not known:
                                held = entry
                    if progress is not None:
                        progress(0.0, entry.pathname or guid)
        except (tarfile.TarError, EOFError, OSError) as exc:
            raise PackageError(f"cannot read {self.path.name}: {exc}") from exc

        if not entries:
            raise PackageError(f"{self.path.name} does not look like a unitypackage (no GUID entries)")

        # pathname が離れた位置にあったものも、判明した拡張子で残すか決め直す
        for entry in entries.values():
            if entry._cache is not None and entry.ext not in _CACHE_EXTS:
                entry._cache = None

        self.entries = entries
        self._scanned = True
        return entries

    # ---------------------------------------------------------------- lookup
    def _require_scan(self) -> None:
        if not self._scanned:
            self.scan()

    def by_kind(self, kind: str) -> list[AssetEntry]:
        self._require_scan()
        return sorted((e for e in self.entries.values() if e.kind == kind), key=lambda e: e.pathname)

    def models(self) -> list[AssetEntry]:
        return self.by_kind("model")

    def materials(self) -> list[AssetEntry]:
        return self.by_kind("material")

    def textures(self) -> list[AssetEntry]:
        return self.by_kind("texture")

    def prefabs(self) -> list[AssetEntry]:
        return self.by_kind("prefab")

    def scenes(self) -> list[AssetEntry]:
        return self.by_kind("scene")

    def get(self, guid: str) -> AssetEntry | None:
        self._require_scan()
        return self.entries.get(guid.lower())

    def find_by_path(self, pathname: str) -> AssetEntry | None:
        self._require_scan()
        for entry in self.entries.values():
            if entry.pathname == pathname:
                return entry
        return None

    # ------------------------------------------------------------- read/extract
    def read_asset(self, guid: str) -> bytes:
        """小さなアセット（.mat など）の実体を返す。キャッシュに無ければ再走査する。

        メモリへ丸ごと載せるので ``_READ_ASSET_MAX_SIZE`` を超えるものは ``PackageError``。
        大きなファイル（モデル・テクスチャ）は ``extract`` でディスクに書き出す。
        """
        entry = self.get(guid)
        if entry is None or not entry.has_asset:
            raise KeyError(guid)
        if entry._cache is not None:
            return entry._cache
        if entry.size > _READ_ASSET_MAX_SIZE:
            raise PackageError(
                f"{entry.pathname or guid} is too large to read into memory "
                f"({entry.size} bytes > {_READ_ASSET_MAX_SIZE} byte limit)"
            )
        target = f"{entry.guid}/asset"
        try:
            with tarfile.open(self.path, "r:*") as tar:
                for member in tar:
                    split = _split_member(member.name)
                    if split and split[0] == entry.guid and split[1] == "asset":
                        if member.size > _READ_ASSET_MAX_SIZE:  # 索引と食い違う場合の保険
                            raise PackageError(f"{target} is too large to read into memory ({member.size} bytes)")
                        return tar.extractfile(member).read()
        except (tarfile.TarError, EOFError, OSError) as exc:  # scan と同じく PackageError に揃える
            raise PackageError(f"cannot read {entry.pathname or target} from {self.path.name}: {exc}") from exc
        raise KeyError(f"{target} not found in {self.path.name}")

    def cached_asset(self, guid: str) -> bytes | None:
        """走査で読み込んだ実体（.mat / .prefab / .unity など）。キャッシュに無ければ再走査せずに None。"""
        entry = self.get(guid)
        return entry._cache if entry is not None else None

    def read_assets(self, guids: Iterable[str]) -> dict[str, bytes]:
        """小さなアセットの実体をまとめて読む。キャッシュに無いものは 1 回の再走査で読む（#130: Volume のプロファイル）。

        無い GUID と ``_READ_ASSET_MAX_SIZE`` を超えるものは結果に入れない。
        """
        result: dict[str, bytes] = {}
        wanted: set[str] = set()
        for guid in guids:
            entry = self.get(guid)
            if entry is None or not entry.has_asset or entry.size > _READ_ASSET_MAX_SIZE:
                continue
            if entry._cache is not None:
                result[entry.guid] = entry._cache
            else:
                wanted.add(entry.guid)
        if not wanted:
            return result
        try:
            with tarfile.open(self.path, "r:*") as tar:
                for member in tar:
                    split = _split_member(member.name)
                    if split and split[1] == "asset" and split[0] in wanted and member.size <= _READ_ASSET_MAX_SIZE:
                        result[split[0]] = tar.extractfile(member).read()
                        wanted.discard(split[0])
                        if not wanted:
                            break
        except (tarfile.TarError, EOFError, OSError) as exc:
            raise PackageError(f"cannot read assets from {self.path.name}: {exc}") from exc
        return result

    def read_text(self, guid: str) -> str:
        return self.read_asset(guid).decode("utf-8", "replace")

    def extract(
        self,
        guids: Iterable[str],
        dest_root: str | Path,
        *,
        overwrite: bool = False,
        progress: ProgressFn | None = None,
        max_total_size: int = 0,
        written: set[str] | None = None,
    ) -> dict[str, Path]:
        """指定 GUID の ``asset`` を ``dest_root/<pathname>`` に書き出し、GUID → パスを返す。

        ``overwrite=False`` なら、既にあるファイルのうち、展開先の記録（``EXTRACT_RECORD_NAME``）で元の tar メンバーの
        GUID・サイズ・更新時刻が一致するものは書き出さない。サイズだけでは、同じ名前・同じサイズの別のファイル
        （同じアセットの新しい版など）と区別できないため（#72）。実際に書き出した GUID は ``written`` に加える。
        書き出す合計サイズ（tar ヘッダー基準。gzip / sparse で小さく見せていても実際に書く量）が
        ``max_total_size``（0 は無制限）を超えるか、展開先の空き容量に収まらなければ何も書かずに ``PackageError``。
        """
        self._require_scan()
        dest_root = Path(dest_root)
        wanted: dict[str, AssetEntry] = {}
        for guid in guids:
            entry = self.get(guid)
            if entry is not None and entry.has_asset and entry.pathname:
                wanted[entry.guid] = entry

        record = _load_record(dest_root)
        result: dict[str, Path] = {}
        pending: dict[str, Path] = {}
        for guid, entry in wanted.items():
            relative = safe_relative_path(entry.pathname)
            target = dest_root / relative
            _reject_symlinks(dest_root, target)
            result[guid] = target
            if (
                not overwrite
                and target.is_file()
                and target.stat().st_size == entry.size
                and record.get(str(relative)) == _identity(entry)
            ):
                continue
            pending[guid] = target

        if not pending:
            return result

        total = sum(wanted[g].size for g in pending)
        if max_total_size and total > max_total_size:
            raise PackageError(
                f"extracting {len(pending)} files needs {human_size(total)}, "
                f"more than the {human_size(max_total_size)} limit set in the add-on preferences"
            )
        free = _free_disk_space(dest_root)
        if free is not None and total > free:
            raise PackageError(
                f"not enough free disk space in {dest_root}: need {human_size(total)}, {human_size(free)} available"
            )

        done = 0
        with tarfile.open(self.path, "r:*") as tar:
            for member in tar:
                split = _split_member(member.name)
                if not split or split[1] != "asset" or split[0] not in pending:
                    continue
                target = pending.pop(split[0])
                target.parent.mkdir(parents=True, exist_ok=True)
                _reject_symlinks(dest_root, target)  # mkdir 後にもう一度（途中の要素が作られた直後の状態で確認）
                src = tar.extractfile(member)
                with _open_for_write(target) as dst:
                    while chunk := src.read(1 << 20):
                        dst.write(chunk)
                done += 1
                entry = wanted[split[0]]
                record[str(safe_relative_path(entry.pathname))] = _identity(entry)
                if written is not None:
                    written.add(entry.guid)
                if progress is not None:
                    progress(done / (done + len(pending)), target.name)
                if not pending:
                    break
        _save_record(dest_root, record)
        return result
