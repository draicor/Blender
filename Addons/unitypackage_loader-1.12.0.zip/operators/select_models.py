"""インポートの 2 段目: 読み込む単位（Scenes / Prefabs / Models）を選び、その候補から読み込むものを選ぶダイアログ。

``IMPORT_SCENE_OT_unitypackage`` が ``prepare_package`` の結果を ``set_pending`` で渡し、
``INVOKE_DEFAULT`` でこのオペレーターを呼ぶ。ダイアログの OK で ``run_import`` を実行する。

単位は排他で、一覧にはいま選んでいる単位の候補だけを出す（同じモデルの二重読み込みを構造上起こさない）。
候補は推測で外さず、読み込めないものは灰色にして理由を表示する。
"""

from __future__ import annotations

import traceback
from dataclasses import dataclass
from typing import TYPE_CHECKING

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, StringProperty

from ..core.package import PackageError, human_size
from ..core.report import sanitize_display
from ..core.units import (
    NO_MESH_REASON,
    NO_SCENE_MESH_REASON,
    UNIT_MODELS,
    UNIT_PREFABS,
    UNIT_SCENES,
    UNREADABLE_SCENE_REASON,
    available_units,
    default_unit,
)
from ..ui.preferences import ARRANGE_ITEMS, UNIT_ITEMS, get_prefs

if TYPE_CHECKING:
    from ..blender.importer import ImportOptions, PreparedPackage


@dataclass
class _Pending:
    filepath: str
    opts: ImportOptions
    prepared: PreparedPackage | None  # execute の後は手放す（全 .mat / .prefab / .unity のバイト列とシーンの階層を持つため）


_pending: _Pending | None = None


def set_pending(filepath: str, opts, prepared) -> None:
    global _pending
    _pending = _Pending(filepath, opts, prepared)


def _release_prepared() -> None:
    """解析結果を手放す。ファイルとオプションは残し、やり直し（Adjust Last Operation）で execute が
    もう一度呼ばれたときはパッケージを解析し直す（#76）。
    """
    if _pending is not None:
        _pending.prepared = None


def _short_reason(reason: str) -> str:
    """行の右端に出す、読み込めない理由の短い表記。"""
    from ..blender.importer import BLEND_DISABLED_REASON, COLLADA_UNAVAILABLE_REASON

    if reason == BLEND_DISABLED_REASON:
        return ".blend import disabled"
    if reason == COLLADA_UNAVAILABLE_REASON:
        return "not supported in Blender 5"
    if reason in (NO_MESH_REASON, NO_SCENE_MESH_REASON, UNREADABLE_SCENE_REASON):
        return reason
    return "unsupported format"


def _plural(count: int, word: str) -> str:
    return f"{count} {word}" if count == 1 else f"{count} {word}s"


_UNIT_ICONS = {UNIT_SCENES: "SCENE_DATA", UNIT_PREFABS: "PACKAGE", UNIT_MODELS: "MESH_DATA"}
_UNIT_NUMBERS = {UNIT_PREFABS: 0, UNIT_MODELS: 1, UNIT_SCENES: 2}

# EnumProperty の動的 items は Python 側で文字列を保持しておかないと表示が壊れるので、モジュールで持つ
_unit_enum_cache: list[tuple[str, str, str, str, int]] = []


def _unit_items(self, context):
    """単位の切り替え。候補が 1 つも無い単位は出さない。ラベルに候補数を付ける。"""
    if _pending is not None and _pending.prepared is None and _unit_enum_cache:
        return _unit_enum_cache  # 解析結果を手放した後（やり直しのパネル）は、ダイアログで出した選択肢のまま
    labels = {identifier: (name, description) for identifier, name, description in UNIT_ITEMS}
    counts = {UNIT_SCENES: 0, UNIT_PREFABS: 0, UNIT_MODELS: 0}
    units: list[str] = []
    if _pending is not None:
        prepared = _pending.prepared
        # シーンの数は展開しなくても分かる（展開は Scenes を開くときまで遅らせる。#75）
        counts = {UNIT_SCENES: len(prepared.scene_entries), UNIT_PREFABS: len(prepared.prefabs), UNIT_MODELS: len(prepared.models)}
        units = available_units(prepared.prefabs, len(prepared.models), prepared.scene_entries)
    _unit_enum_cache[:] = [
        (unit, f"{labels[unit][0]} ({counts[unit]})", labels[unit][1], _UNIT_ICONS[unit], _UNIT_NUMBERS[unit])
        for unit in units or [UNIT_MODELS]
    ]
    return _unit_enum_cache


def _add_scene_items(items, prepared) -> None:
    """シーンを展開して候補に加える（加え済みなら何もしない）。

    既定でチェックを入れるのは、一覧の順で最初の読み込めるシーンだけ（#134）。シーンをまとめて読み込むことはほとんど無く、
    同じ場所の時間違いのシーンが多いので、まとめて読むと建物やライトが重なる。候補はすべて出す。
    """
    if any(it.kind == UNIT_SCENES for it in items):
        return
    chosen = False
    for s in prepared.scenes:
        item = items.add()
        item.kind = UNIT_SCENES
        item.guid = s.guid
        item.pathname = sanitize_display(s.pathname)
        if s.supported:
            models = len(s.contents.model_guids) if s.contents is not None else 0
            item.detail_text = f"{len(s.placements)} placed · {_plural(models, 'model')}"
        else:
            item.detail_text = _short_reason(s.skip_reason)
        item.supported = s.supported
        item.selected = s.supported and not chosen
        chosen = chosen or s.supported


def _on_unit_changed(self, context):
    """Scenes に切り替えたとき、まだ展開していなければシーンを展開して候補に加える（#75）。"""
    if _pending is None or _pending.prepared is None or getattr(self, _UNIT_PROP) != UNIT_SCENES:
        return
    window = context.window
    if window is not None:
        window.cursor_set("WAIT")
    try:
        _add_scene_items(getattr(self, _ITEMS_PROP), _pending.prepared)
    finally:
        if window is not None:
            window.cursor_set("DEFAULT")


class UNITYPKG_ImportItem(bpy.types.PropertyGroup):
    kind: StringProperty()  # UNIT_SCENES / UNIT_PREFABS / UNIT_MODELS
    guid: StringProperty()
    pathname: StringProperty()  # 表示用（sanitize_display 済み）
    size_text: StringProperty()
    detail_text: StringProperty()
    selected: BoolProperty(default=True)
    supported: BoolProperty(default=True)


class UNITYPKG_UL_import_items(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        sub = row.row(align=True)
        sub.enabled = item.supported
        sub.prop(item, "selected", text="")
        sub.label(text=item.pathname, icon=_UNIT_ICONS.get(item.kind, "DOT") if item.supported else "ERROR")
        right = row.row(align=True)
        right.alignment = "RIGHT"
        right.enabled = item.supported
        if item.size_text:
            right.label(text=item.size_text)
        right.label(text=item.detail_text)

    def filter_items(self, context, data, propname):
        """いま選んでいる単位の候補だけを表示する（名前での絞り込みも効かせる）。"""
        items = getattr(data, propname)
        unit = getattr(context.window_manager, _UNIT_PROP)
        if self.filter_name:
            flags = bpy.types.UI_UL_list.filter_items_by_name(
                self.filter_name, self.bitflag_filter_item, items, "pathname", reverse=self.use_filter_invert
            )
        else:
            flags = [self.bitflag_filter_item] * len(items)
        flags = [flag if item.kind == unit else 0 for flag, item in zip(flags, items)]
        return flags, []


_ITEMS_PROP = "unitypkg_select_models"
_INDEX_PROP = "unitypkg_select_models_index"
_UNIT_PROP = "unitypkg_select_unit"
_ARRANGE_PROP = "unitypkg_select_arrange"
_LIGHTS_PROP = "unitypkg_select_lights"
_CAMERAS_PROP = "unitypkg_select_cameras"
_EXPOSURE_PROP = "unitypkg_select_exposure"
_LODS_PROP = "unitypkg_select_hide_lods"
_UNUSED_PROP = "unitypkg_select_skip_unused"


def _items(context):
    """ダイアログの候補一覧（WindowManager 側。ダイアログ内のボタンからも触れるようにするため）。"""
    return getattr(context.window_manager, _ITEMS_PROP)


def _current_unit(context) -> str:
    return getattr(context.window_manager, _UNIT_PROP)


class IMPORT_SCENE_OT_unitypackage_select(bpy.types.Operator):
    bl_idname = "import_scene.unitypackage_select"
    bl_label = "Import from Unitypackage"
    bl_description = "Choose what to import from the package: scenes, prefabs or model files"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    package_name: StringProperty()
    summary_materials: StringProperty()
    summary_textures: StringProperty()

    def invoke(self, context, event):
        if _pending is None:
            self.report({"ERROR"}, "No pending package to import")
            return {"CANCELLED"}
        prepared = _pending.prepared
        items = _items(context)
        items.clear()
        for p in prepared.prefabs:
            item = items.add()
            item.kind = UNIT_PREFABS
            item.guid = p.guid
            item.pathname = sanitize_display(p.pathname)
            if p.supported:
                item.detail_text = f"{_plural(len(p.model_guids), 'model')} · {len(p.material_guids)} mat"
            else:
                item.detail_text = _short_reason(p.skip_reason)
            item.supported = p.supported
            item.selected = p.supported
        for m in prepared.models:
            item = items.add()
            item.kind = UNIT_MODELS
            item.guid = m.guid
            item.pathname = sanitize_display(m.entry.pathname)
            item.size_text = human_size(m.entry.size)
            if m.supported:
                item.detail_text = f"{m.resolved_count}/{m.material_count} mat" if m.material_count else "no mat info"
            else:
                item.detail_text = _short_reason(m.skip_reason)
            item.supported = m.supported
            item.selected = m.supported

        wm = context.window_manager
        prefs = get_prefs(context)
        last_unit = prefs.last_import_unit if prefs is not None else ""
        # シーンの展開は重いので、Scenes が既定になりうるとき（前回が Scenes か、ほかに読み込めるものが無い）だけここで行い、
        # それ以外は Scenes に切り替えたときに行う（_on_unit_changed。#75）。既定の順では Scenes は最後なので、展開しなくても決まる
        others = any(p.supported for p in prepared.prefabs) or bool(prepared.supported_models)
        if prepared.scene_entries and (last_unit == UNIT_SCENES or not others):
            _add_scene_items(items, prepared)
        scenes = prepared.scenes if prepared.scenes_expanded else ()
        setattr(wm, _UNIT_PROP, default_unit(prepared.prefabs, len(prepared.supported_models), last_unit, scenes))
        setattr(wm, _ARRANGE_PROP, prefs.default_arrange if prefs is not None else _pending.opts.arrange)

        self.package_name = sanitize_display(prepared.path.name)
        self.summary_materials = f"Materials: {len(prepared.unity_mats)} found in package"
        ref, missing = len(prepared.referenced_textures), len(prepared.missing_textures)
        self.summary_textures = f"Textures: {ref} referenced" + (f", {missing} missing from package" if missing else "")
        return wm.invoke_props_dialog(self, width=640, confirm_text="Import")

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        unit = _current_unit(context)
        items = _items(context)
        visible = [it for it in items if it.kind == unit]

        layout.label(text=self.package_name, icon="PACKAGE")
        layout.row().prop(wm, _UNIT_PROP, expand=True)
        layout.template_list(
            "UNITYPKG_UL_import_items", "", wm, _ITEMS_PROP, wm, _INDEX_PROP, rows=min(max(len(visible), 3), 10)
        )
        row = layout.row(align=True)
        row.operator("unitypkg.select_models_all", text="All").select = True
        row.operator("unitypkg.select_models_all", text="None").select = False

        if unit == UNIT_PREFABS:
            # 並べ方は 2 つ以上選んだときだけ効く。行を出し入れするとダイアログの高さと Import ボタンの位置が
            # 変わるので、常に出しておき、1 つ以下のときは淡色にする
            split = layout.split(factor=0.2)
            split.active = sum(1 for it in visible if it.selected and it.supported) > 1
            split.label(text="Arrange")
            split.row().prop(wm, _ARRANGE_PROP, expand=True)
        elif unit == UNIT_SCENES:
            split = layout.split(factor=0.2)
            split.label(text="Also Import")
            row = split.row(align=True)
            row.prop(wm, _LIGHTS_PROP, toggle=True, icon="LIGHT")
            row.prop(wm, _CAMERAS_PROP, toggle=True, icon="CAMERA_DATA")
            row.prop(wm, _EXPOSURE_PROP, toggle=True, icon="LIGHT_SUN")

        if unit in (UNIT_PREFABS, UNIT_SCENES):
            # LODGroup を持つ prefab・シーンだけに効く。タブを切り替えても高さが変わらないよう、両方に出す
            split = layout.split(factor=0.2)
            split.label(text="LODs")
            split.prop(wm, _LODS_PROP, toggle=True, icon="MOD_DECIM")
            # prefab・シーンが FBX の一部のメッシュだけを使うときに機能する（#152）
            split = layout.split(factor=0.2)
            split.label(text="Unused Parts")
            split.prop(wm, _UNUSED_PROP, toggle=True, icon="TRASH")

        col = layout.column(align=True)
        col.label(text=self.summary_materials, icon="MATERIAL")
        col.label(text=self.summary_textures, icon="TEXTURE")

    def execute(self, context):
        try:
            return self._execute(context)
        finally:
            _release_prepared()

    def cancel(self, context):
        global _pending
        _pending = None  # ダイアログを閉じた（やり直しも無い）ので、すべて手放す（#76）

    def _execute(self, context):
        from ..blender.importer import build_shader_table, prepare_package, run_import

        if _pending is None:
            self.report({"ERROR"}, "No pending package to import")
            return {"CANCELLED"}
        wm = context.window_manager
        unit = _current_unit(context)
        arrange = getattr(wm, _ARRANGE_PROP)
        chosen = {it.guid for it in _items(context) if it.kind == unit and it.selected and it.supported}
        if not chosen:
            self.report({"WARNING"}, "Nothing selected to import")
            return {"CANCELLED"}
        opts = _pending.opts
        prepared = _pending.prepared
        if prepared is None:  # やり直し。前回の execute の後で解析結果を手放している
            try:
                prepared = prepare_package(
                    _pending.filepath, build_shader_table(opts.shader_table_path), import_blend=opts.import_blend
                )
            except PackageError as exc:
                self.report({"ERROR"}, sanitize_display(str(exc)))
                return {"CANCELLED"}
        opts.unit = unit
        opts.arrange = arrange
        opts.scene_lights = getattr(wm, _LIGHTS_PROP)
        opts.scene_cameras = getattr(wm, _CAMERAS_PROP)
        opts.scene_exposure = getattr(wm, _EXPOSURE_PROP)
        opts.hide_lods = getattr(wm, _LODS_PROP)
        opts.skip_unused_parts = getattr(wm, _UNUSED_PROP)
        opts.scene_paths = opts.prefab_paths = opts.model_guids = None
        if unit == UNIT_SCENES:
            opts.scene_paths = [s.pathname for s in prepared.scenes if s.guid in chosen]
        elif unit == UNIT_PREFABS:
            opts.prefab_paths = [p.pathname for p in prepared.prefabs if p.guid in chosen]
        else:
            opts.model_guids = [m.guid for m in prepared.models if m.guid in chosen]

        prefs = get_prefs(context)
        if prefs is not None:
            # 次に開いたときの既定にする（並べ方は Preferences の既定値そのものを更新する）
            prefs.last_import_unit = unit
            if unit == UNIT_PREFABS:
                prefs.default_arrange = arrange

        wm.progress_begin(0, 100)
        try:
            report = run_import(
                context,
                _pending.filepath,
                opts,
                progress=lambda f, msg: wm.progress_update(int(f * 100)),
                prepared=prepared,
            )
        except PackageError as exc:
            self.report({"ERROR"}, sanitize_display(str(exc)))
            return {"CANCELLED"}
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            self.report({"ERROR"}, sanitize_display(f"Import failed: {exc!r}"))
            return {"CANCELLED"}
        finally:
            wm.progress_end()

        if prefs is None or prefs.verbose_log:
            print(report.as_text())
        self.report({"WARNING" if report.warnings or report.errors else "INFO"}, report.summary())
        return {"FINISHED"}


class UNITYPKG_OT_select_models_all(bpy.types.Operator):
    """ダイアログ内の All / None ボタン。いま表示している単位の候補だけを切り替える。

    ダイアログが開いている間は ``context.active_operator`` がダイアログを指さない（None になる）ため、
    候補一覧は WindowManager 側に置き、ここから直接書き換える。"""

    bl_idname = "unitypkg.select_models_all"
    bl_label = "Select All"
    bl_options = {"INTERNAL"}

    select: BoolProperty(default=True)

    def execute(self, context):
        items = _items(context)
        if not items:
            return {"CANCELLED"}
        unit = _current_unit(context)
        for it in items:
            if it.supported and it.kind == unit:
                it.selected = self.select
        return {"FINISHED"}


_classes = (
    UNITYPKG_ImportItem,
    UNITYPKG_UL_import_items,
    UNITYPKG_OT_select_models_all,
    IMPORT_SCENE_OT_unitypackage_select,
)


def register() -> None:
    for cls in _classes:
        bpy.utils.register_class(cls)
    wm = bpy.types.WindowManager
    setattr(wm, _ITEMS_PROP, CollectionProperty(type=UNITYPKG_ImportItem))
    setattr(wm, _INDEX_PROP, IntProperty(default=0))
    setattr(wm, _UNIT_PROP, EnumProperty(name="Import Unit", items=_unit_items, update=_on_unit_changed))
    setattr(wm, _ARRANGE_PROP, EnumProperty(name="Arrange", items=ARRANGE_ITEMS, default="SIDE_BY_SIDE"))
    setattr(wm, _LIGHTS_PROP, BoolProperty(name="Lights", default=True, description="Import the scene's lights"))
    setattr(wm, _CAMERAS_PROP, BoolProperty(name="Cameras", default=True, description="Import the scene's cameras"))
    setattr(wm, _EXPOSURE_PROP, BoolProperty(
        name="Exposure",
        default=True,
        description=(
            "Scale the HDRP scene's lights by its Volume exposure, so the physical light units look as bright as in Unity. "
            "The Blender scene's exposure is left unchanged. Automatic exposure is approximated with its upper limit"
        ),
    ))
    setattr(wm, _LODS_PROP, BoolProperty(
        name="Hide Distant Levels",
        default=True,
        description=(
            "Hide the distant LOD levels of Unity LODGroups, so only the most detailed mesh is visible. "
            "The hidden objects stay in the file and keep their level in the 'unity_lod' custom property"
        ),
    ))
    setattr(wm, _UNUSED_PROP, BoolProperty(
        name="Skip Unused Parts",
        default=True,
        description=(
            "Do not import the parts of a model file that the Unity prefabs or scene do not use, "
            "such as the other pieces of a model file that bundles many props. "
            "Turn off to import them hidden, as before"
        ),
    ))


def unregister() -> None:
    for prop in (_UNUSED_PROP, _LODS_PROP, _EXPOSURE_PROP, _CAMERAS_PROP, _LIGHTS_PROP, _ARRANGE_PROP, _UNIT_PROP, _INDEX_PROP, _ITEMS_PROP):
        if hasattr(bpy.types.WindowManager, prop):
            delattr(bpy.types.WindowManager, prop)
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
