import bpy
from bpy_extras.view3d_utils import location_3d_to_region_2d

from ..utils.grid_images import attach_grid_background
from ..utils.outline import BPK_OUTLINE_GROUP_NODE_NAME
from ..utils.outline import apply_outline_settings_to_tree
from ..utils.status import set_status
from ..utils.viewport_preview import VIEWPORT_PIXEL_GROUP_NAME
from ..utils.viewport_preview import VIEWPORT_PIXEL_GROUP_NODE_NAME
from ..utils.viewport_preview import VIEWPORT_PIXEL_DOWNSCALE_NODE_NAME
from ..utils.viewport_preview import VIEWPORT_PIXEL_UPSCALE_NODE_NAME
from ..utils.viewport_preview import VIEWPORT_PIXEL_VALUE_NODE_NAME
from ..utils.viewport_preview import VIEWPORT_PIXEL_VIEWER_NODE_NAME
from ..utils.viewport_preview import get_scene_compositor_tree
from ..utils.viewport_preview import set_viewport_pixel_transform
from ..utils.viewport_display import set_viewport_render_preview


def _ensure_group_socket(node_tree, name, in_out):
    if hasattr(node_tree, "interface"):
        for item in node_tree.interface.items_tree:
            if item.item_type == "SOCKET" and item.name == name and item.in_out == in_out:
                return

        node_tree.interface.new_socket(
            name=name,
            in_out=in_out,
            socket_type="NodeSocketColor",
        )
        return

    sockets = node_tree.inputs if in_out == "INPUT" else node_tree.outputs

    if name not in sockets:
        sockets.new("NodeSocketColor", name)


def _set_node_property(node, property_name, value):
    if not hasattr(node, property_name):
        return

    try:
        setattr(node, property_name, value)
    except TypeError:
        pass


def _configure_transform_node(node):
    _set_node_property(node, "filter_type", "NEAREST")
    _set_node_property(node, "interpolation", "NEAREST")
    _set_node_property(node, "extension", "CLIP")

    for input_name, value in (
        ("Interpolation", "Nearest"),
        ("Extension X", "Clip"),
        ("Extension Y", "Clip"),
    ):
        socket = node.inputs.get(input_name)

        if socket is None or not hasattr(socket, "default_value"):
            continue

        try:
            socket.default_value = value
        except TypeError:
            pass


def _replace_input_link(node_tree, input_socket, output_socket):
    for link in list(input_socket.links):
        node_tree.links.remove(link)

    node_tree.links.new(output_socket, input_socket)


def _get_or_create_node(node_tree, node_type, name):
    node = node_tree.nodes.get(name)

    if node is not None and node.bl_idname == node_type:
        return node

    node = node_tree.nodes.new(node_type)
    node.name = name
    node.label = name

    return node


def _new_node(node_tree, node_types):
    for node_type in node_types:
        try:
            return node_tree.nodes.new(node_type)
        except RuntimeError:
            continue

    raise RuntimeError(f"Could not create any of these node types: {node_types}")


def _get_socket(sockets, name, fallback_index=0):
    socket = sockets.get(name)

    if socket is not None:
        return socket

    return sockets[fallback_index]


def _get_view3d_window_region(context):
    area = context.area

    if area is None or area.type != "VIEW_3D":
        return None

    for region in area.regions:
        if region.type == "WINDOW":
            return region

    return None


def _get_context_region_3d(context):
    space = context.space_data

    if space is None or space.type != "VIEW_3D":
        return None

    return space.region_3d


def _get_preview_camera(context):
    scene = context.scene

    if scene.camera is not None:
        return scene.camera

    active_object = context.view_layer.objects.active

    if active_object is not None and active_object.type == "CAMERA":
        return active_object

    return None


def _resolution_label(width, height):
    return f"{width}x{height}"


def _rename_preview_camera_for_resolution(camera_object, width, height):
    label = _resolution_label(width, height)

    if camera_object.name.startswith("BPK Iso"):
        camera_object.name = f"BPK Iso {label} Camera"
    elif camera_object.name.startswith("BPK Pixel"):
        camera_object.name = f"BPK Pixel {label} Camera"
    else:
        return False

    if camera_object.data is not None:
        camera_object.data.name = camera_object.name

    return True


def _refresh_preview_camera_grid(context):
    camera_object = _get_preview_camera(context)

    if camera_object is None:
        return None

    addon_settings = context.scene.blender_pixel_kit_settings
    width = max(1, addon_settings.current_resolution_x)
    height = max(1, addon_settings.current_resolution_y)

    _rename_preview_camera_for_resolution(camera_object, width, height)
    attach_grid_background(
        camera_object.data,
        width,
        height,
        addon_settings.grid_opacity,
    )
    context.scene.camera = camera_object

    return camera_object, width, height


def _calculate_viewport_preview_transform(context):
    scene = context.scene
    region = _get_view3d_window_region(context)
    region_3d = _get_context_region_3d(context)
    camera_object = _get_preview_camera(context)

    if region is None or region_3d is None:
        raise RuntimeError("Run this from a 3D View.")

    if camera_object is None:
        raise RuntimeError("No active scene camera found.")

    frame_points = [
        camera_object.matrix_world @ point
        for point in camera_object.data.view_frame(scene=scene)
    ]
    screen_points = [
        location_3d_to_region_2d(region, region_3d, point)
        for point in frame_points
    ]

    if any(point is None for point in screen_points):
        raise RuntimeError("Camera frame is not visible in the current viewport.")

    min_x = min(point.x for point in screen_points)
    max_x = max(point.x for point in screen_points)
    visible_camera_width = max_x - min_x

    if visible_camera_width <= 0.0:
        raise RuntimeError("Camera frame has no visible width in the viewport.")

    render_width = max(1, scene.blender_pixel_kit_settings.current_resolution_x)
    preview_resolution = render_width / visible_camera_width

    return (
        max(0.001, min(1.0, preview_resolution)),
        visible_camera_width,
        scene.blender_pixel_kit_settings.viewport_preview_offset_x,
        scene.blender_pixel_kit_settings.viewport_preview_offset_y,
    )


def _update_viewport_preview_resolution(context):
    addon_settings = context.scene.blender_pixel_kit_settings
    (
        preview_resolution,
        visible_camera_width,
        offset_x,
        offset_y,
    ) = _calculate_viewport_preview_transform(context)

    set_viewport_pixel_transform(
        context.scene,
        preview_resolution,
        offset_x,
        offset_y,
    )
    addon_settings.viewport_preview_scale = preview_resolution
    node_tree = get_scene_compositor_tree(context.scene)

    if node_tree is not None:
        apply_outline_settings_to_tree(
            node_tree,
            addon_settings.outline_thickness,
            addon_settings.outline_color,
            addon_settings.outline_background_color,
            preview_resolution,
        )

    print(
        "[Blender Pixel Kit] Viewport preview resolution updated: "
        f"{preview_resolution:g} "
        f"({addon_settings.current_resolution_x}px render / "
        f"{visible_camera_width:.1f}px viewport camera width)."
    )

    return preview_resolution, visible_camera_width, offset_x, offset_y


def _ensure_viewport_pixel_group(preview_scale, offset_x=0.0, offset_y=0.0):
    group = bpy.data.node_groups.get(VIEWPORT_PIXEL_GROUP_NAME)

    if group is None or group.bl_idname != "CompositorNodeTree":
        group = bpy.data.node_groups.new(
            VIEWPORT_PIXEL_GROUP_NAME,
            "CompositorNodeTree",
        )

    group.nodes.clear()
    _ensure_group_socket(group, "Image", "INPUT")
    _ensure_group_socket(group, "Image", "OUTPUT")

    input_node = group.nodes.new("NodeGroupInput")
    input_node.location = (-700, 100)

    output_node = group.nodes.new("NodeGroupOutput")
    output_node.location = (550, 100)

    value_node = _new_node(group, ("ShaderNodeValue", "CompositorNodeValue"))
    value_node.name = VIEWPORT_PIXEL_VALUE_NODE_NAME
    value_node.label = "Viewport Resolution"
    value_node.location = (-700, -180)
    value_node.outputs[0].default_value = preview_scale

    scale_down_node = group.nodes.new("CompositorNodeTransform")
    scale_down_node.name = VIEWPORT_PIXEL_DOWNSCALE_NODE_NAME
    scale_down_node.label = "Pixel Preview Downscale"
    scale_down_node.location = (-350, 60)
    _configure_transform_node(scale_down_node)
    _get_socket(scale_down_node.inputs, "X", 1).default_value = -offset_x
    _get_socket(scale_down_node.inputs, "Y", 2).default_value = -offset_y

    # Blender 5.x can ignore transform-to-transform chains here. The Gamma node
    # is intentionally neutral and keeps the viewer chain reliable.
    gamma_node = _new_node(group, ("ShaderNodeGamma", "CompositorNodeGamma"))
    gamma_node.label = "Transform Spacer"
    gamma_node.location = (-50, 60)

    divide_node = _new_node(group, ("ShaderNodeMath", "CompositorNodeMath"))
    divide_node.operation = "DIVIDE"
    divide_node.label = "Inverse Scale"
    divide_node.location = (-250, -180)
    divide_node.inputs[0].default_value = 1.0

    scale_up_node = group.nodes.new("CompositorNodeTransform")
    scale_up_node.name = VIEWPORT_PIXEL_UPSCALE_NODE_NAME
    scale_up_node.label = "Pixel Preview Upscale"
    scale_up_node.location = (250, 60)
    _configure_transform_node(scale_up_node)
    _get_socket(scale_up_node.inputs, "X", 1).default_value = offset_x
    _get_socket(scale_up_node.inputs, "Y", 2).default_value = offset_y

    group.links.new(
        _get_socket(input_node.outputs, "Image"),
        _get_socket(scale_down_node.inputs, "Image"),
    )
    group.links.new(
        value_node.outputs[0],
        _get_socket(scale_down_node.inputs, "Scale", 3),
    )
    group.links.new(
        _get_socket(scale_down_node.outputs, "Image"),
        _get_socket(gamma_node.inputs, "Image"),
    )
    group.links.new(
        _get_socket(gamma_node.outputs, "Image"),
        _get_socket(scale_up_node.inputs, "Image"),
    )
    group.links.new(value_node.outputs[0], divide_node.inputs[1])
    group.links.new(
        divide_node.outputs[0],
        _get_socket(scale_up_node.inputs, "Scale", 3),
    )
    group.links.new(
        _get_socket(scale_up_node.outputs, "Image"),
        _get_socket(output_node.inputs, "Image"),
    )

    return group


def _find_node_by_type(node_tree, node_type):
    for node in node_tree.nodes:
        if node.bl_idname == node_type:
            return node

    return None


def _ensure_scene_output_socket(node_tree):
    if not hasattr(node_tree, "interface"):
        return

    for item in node_tree.interface.items_tree:
        if item.item_type == "SOCKET" and item.name == "Image" and item.in_out == "OUTPUT":
            return

    node_tree.interface.new_socket(
        name="Image",
        in_out="OUTPUT",
        socket_type="NodeSocketColor",
    )


def _ensure_final_output_node(scene, node_tree, render_image_output):
    if hasattr(scene, "compositing_node_group"):
        _ensure_scene_output_socket(node_tree)
        output_node = _find_node_by_type(node_tree, "NodeGroupOutput")

        if output_node is None:
            output_node = node_tree.nodes.new("NodeGroupOutput")
            output_node.location = (500, 220)

        output_image_input = _get_socket(output_node.inputs, "Image")

        if not output_image_input.is_linked:
            node_tree.links.new(render_image_output, output_image_input)

        return

    composite_node = _find_node_by_type(node_tree, "CompositorNodeComposite")

    if composite_node is None:
        composite_node = node_tree.nodes.new("CompositorNodeComposite")
        composite_node.location = (500, 220)

    composite_image_input = _get_socket(composite_node.inputs, "Image")

    if not composite_image_input.is_linked:
        node_tree.links.new(render_image_output, composite_image_input)


def _ensure_scene_nodes(scene, preview_scale, offset_x=0.0, offset_y=0.0):
    node_tree = get_scene_compositor_tree(scene, create=True)

    if node_tree is None:
        raise RuntimeError("Could not create a compositor node tree.")

    render_layers_node = _find_node_by_type(node_tree, "CompositorNodeRLayers")
    if render_layers_node is None:
        render_layers_node = node_tree.nodes.new("CompositorNodeRLayers")
        render_layers_node.location = (-600, 120)

    render_image_output = _get_socket(render_layers_node.outputs, "Image")
    _ensure_final_output_node(scene, node_tree, render_image_output)
    viewport_source_output = render_image_output
    viewport_outline_node = node_tree.nodes.get(BPK_OUTLINE_GROUP_NODE_NAME)

    if viewport_outline_node is not None:
        viewport_source_output = _get_socket(
            viewport_outline_node.outputs,
            "Viewport Image",
            1,
        )

    group = _ensure_viewport_pixel_group(preview_scale, offset_x, offset_y)
    group_node = _get_or_create_node(
        node_tree,
        "CompositorNodeGroup",
        VIEWPORT_PIXEL_GROUP_NODE_NAME,
    )
    group_node.node_tree = group
    group_node.location = (-50, -100)

    viewer_node = _get_or_create_node(
        node_tree,
        "CompositorNodeViewer",
        VIEWPORT_PIXEL_VIEWER_NODE_NAME,
    )
    viewer_node.location = (350, -100)

    _replace_input_link(
        node_tree,
        _get_socket(group_node.inputs, "Image"),
        viewport_source_output,
    )
    _replace_input_link(
        node_tree,
        _get_socket(viewer_node.inputs, "Image"),
        _get_socket(group_node.outputs, "Image"),
    )


def _remove_viewport_pixel_preview(scene):
    node_tree = get_scene_compositor_tree(scene)

    if node_tree is None:
        return 0

    removed_count = 0

    for node_name in (
        VIEWPORT_PIXEL_GROUP_NODE_NAME,
        VIEWPORT_PIXEL_VIEWER_NODE_NAME,
    ):
        node = node_tree.nodes.get(node_name)

        if node is None:
            continue

        node_tree.nodes.remove(node)
        removed_count += 1

    group = bpy.data.node_groups.get(VIEWPORT_PIXEL_GROUP_NAME)

    if group is not None and group.users == 0:
        bpy.data.node_groups.remove(group)

    return removed_count


def _viewport_preview_is_set_up(scene):
    node_tree = get_scene_compositor_tree(scene)

    if node_tree is None:
        return False

    return node_tree.nodes.get(VIEWPORT_PIXEL_GROUP_NODE_NAME) is not None


class PIXEL_PREVIEW_OT_setup_viewport_pixel_preview(bpy.types.Operator):
    """Set up a viewer-only compositor pixel preview."""

    bl_idname = "blender_pixel_kit.setup_viewport_pixel_preview"
    bl_label = "Set up Viewport Preview"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        addon_settings = context.scene.blender_pixel_kit_settings

        set_viewport_render_preview(context, rendered=True)

        try:
            (
                preview_scale,
                visible_camera_width,
                offset_x,
                offset_y,
            ) = _update_viewport_preview_resolution(
                context
            )
        except RuntimeError as error:
            set_status(context, f"(>_<) {error}")
            self.report({"WARNING"}, str(error))
            return {"CANCELLED"}

        _ensure_scene_nodes(context.scene, preview_scale, offset_x, offset_y)
        set_viewport_pixel_transform(context.scene, preview_scale, offset_x, offset_y)

        print(
            "[Blender Pixel Kit] Viewport pixel preview set up at "
            f"{preview_scale:g} preview resolution."
        )
        self.report(
            {"INFO"},
            "Viewport preview set up "
            f"({addon_settings.current_resolution_x}px / "
            f"{visible_camera_width:.1f}px).",
        )
        set_status(context, "(^o^) Viewport pixels snapped.")
        return {"FINISHED"}


class PIXEL_PREVIEW_OT_update_viewport_preview_resolution(bpy.types.Operator):
    """Update preview resolution from the current camera size in the viewport."""

    bl_idname = "blender_pixel_kit.update_viewport_preview_resolution"
    bl_label = "Update Preview Resolution"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        set_viewport_render_preview(context, rendered=True)

        if not _viewport_preview_is_set_up(context.scene):
            set_status(context, "(o_o) Set up viewport preview first.")
            self.report({"WARNING"}, "Set up viewport preview first.")
            return {"CANCELLED"}

        refreshed_camera = _refresh_preview_camera_grid(context)

        try:
            preview_resolution, visible_camera_width, _offset_x, _offset_y = (
                _update_viewport_preview_resolution(context)
            )
        except RuntimeError as error:
            set_status(context, f"(>_<) {error}")
            self.report({"WARNING"}, str(error))
            return {"CANCELLED"}

        report_message = (
            f"Preview resolution set to {preview_resolution:.4f} "
            f"from {visible_camera_width:.1f}px camera width."
        )

        if refreshed_camera is not None:
            _camera_object, width, height = refreshed_camera
            report_message += f" Camera grid refreshed to {width}x{height}."

        self.report({"INFO"}, report_message)
        set_status(context, "(^o^) Preview and camera refreshed.")
        return {"FINISHED"}


class PIXEL_PREVIEW_OT_remove_viewport_pixel_preview(bpy.types.Operator):
    """Remove generated viewport pixel preview compositor nodes."""

    bl_idname = "blender_pixel_kit.remove_viewport_pixel_preview"
    bl_label = "Remove Viewport Preview"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        removed_count = _remove_viewport_pixel_preview(context.scene)

        print(
            "[Blender Pixel Kit] Removed viewport preview node(s): "
            f"{removed_count}."
        )
        self.report({"INFO"}, f"Removed {removed_count} preview node(s).")
        set_status(context, "(._.) Viewport preview removed.")
        return {"FINISHED"}


class PIXEL_PREVIEW_OT_toggle_viewport_display(bpy.types.Operator):
    """Toggle viewport grid, floor, and axis guide visibility."""

    bl_idname = "blender_pixel_kit.toggle_viewport_display"
    bl_label = "Toggle Viewport Overlay"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        space = context.space_data

        if space is None or space.type != "VIEW_3D":
            set_status(context, "(>_<) Run this from a 3D View.")
            self.report({"WARNING"}, "Run this from a 3D View.")
            return {"CANCELLED"}

        overlay = space.overlay
        overlay_properties = (
            "show_floor",
            "show_ortho_grid",
            "show_axis_x",
            "show_axis_y",
            "show_axis_z",
        )
        active_values = [
            getattr(overlay, property_name)
            for property_name in overlay_properties
            if hasattr(overlay, property_name)
        ]

        if not active_values:
            set_status(context, "(o_o) No viewport guides found.")
            self.report({"WARNING"}, "No viewport display toggles found.")
            return {"CANCELLED"}

        should_show = not any(active_values)

        for property_name in overlay_properties:
            if hasattr(overlay, property_name):
                setattr(overlay, property_name, should_show)

        state_label = "shown" if should_show else "hidden"
        print(f"[Blender Pixel Kit] Viewport display guides {state_label}.")
        self.report({"INFO"}, f"Viewport display guides {state_label}.")
        set_status(context, f"(._.) Viewport guides {state_label}.")
        return {"FINISHED"}


classes = (
    PIXEL_PREVIEW_OT_setup_viewport_pixel_preview,
    PIXEL_PREVIEW_OT_update_viewport_preview_resolution,
    PIXEL_PREVIEW_OT_remove_viewport_pixel_preview,
    PIXEL_PREVIEW_OT_toggle_viewport_display,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
