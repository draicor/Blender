import bpy

from ..utils.outline import BPK_OUTLINE_COMPOSITE_NODE_NAME
from ..utils.outline import BPK_OUTLINE_DILATE_NODE_NAME
from ..utils.outline import BPK_OUTLINE_GROUP_NAME
from ..utils.outline import BPK_OUTLINE_GROUP_NODE_NAME
from ..utils.outline import BPK_OUTLINE_MASK_NODE_NAME
from ..utils.outline import BPK_VIEWPORT_OUTLINE_COMPOSITE_NODE_NAME
from ..utils.outline import BPK_VIEWPORT_OUTLINE_DILATE_NODE_NAME
from ..utils.outline import BPK_VIEWPORT_OUTLINE_MASK_NODE_NAME
from ..utils.outline import OUTLINE_NODE_NAMES
from ..utils.outline import get_viewport_outline_thickness
from ..utils.status import set_status
from ..utils.viewport_preview import VIEWPORT_PIXEL_GROUP_NODE_NAME
from ..utils.viewport_preview import get_scene_compositor_tree


def _get_socket(sockets, name, fallback_index=0):
    socket = sockets.get(name)

    if socket is not None:
        return socket

    return sockets[fallback_index]


def _find_node_by_type(node_tree, node_type):
    for node in node_tree.nodes:
        if node.bl_idname == node_type:
            return node

    return None


def _get_or_create_node(node_tree, node_type, name):
    node = node_tree.nodes.get(name)

    if node is not None and node.bl_idname == node_type:
        return node

    if node is not None:
        node_tree.nodes.remove(node)

    node = node_tree.nodes.new(node_type)
    node.name = name
    node.label = name

    return node


def _replace_input_link(node_tree, input_socket, output_socket):
    for link in list(input_socket.links):
        node_tree.links.remove(link)

    node_tree.links.new(output_socket, input_socket)


def _ensure_group_socket(node_tree, name, in_out, socket_type="NodeSocketColor"):
    if hasattr(node_tree, "interface"):
        for item in node_tree.interface.items_tree:
            if item.item_type == "SOCKET" and item.name == name and item.in_out == in_out:
                return

        node_tree.interface.new_socket(
            name=name,
            in_out=in_out,
            socket_type=socket_type,
        )
        return

    sockets = node_tree.inputs if in_out == "INPUT" else node_tree.outputs

    if name not in sockets:
        sockets.new(socket_type, name)


def _ensure_scene_output_socket(node_tree):
    _ensure_group_socket(node_tree, "Image", "OUTPUT")


def _ensure_render_layers_node(node_tree):
    render_layers_node = _find_node_by_type(node_tree, "CompositorNodeRLayers")

    if render_layers_node is None:
        render_layers_node = node_tree.nodes.new("CompositorNodeRLayers")
        render_layers_node.location = (-700, 120)

    return render_layers_node


def _ensure_final_output_node(scene, node_tree):
    if hasattr(scene, "compositing_node_group"):
        _ensure_scene_output_socket(node_tree)
        output_node = _find_node_by_type(node_tree, "NodeGroupOutput")

        if output_node is None:
            output_node = node_tree.nodes.new("NodeGroupOutput")
            output_node.location = (650, 140)

        return output_node

    output_node = _find_node_by_type(node_tree, "CompositorNodeComposite")

    if output_node is None:
        output_node = node_tree.nodes.new("CompositorNodeComposite")
        output_node.location = (650, 140)

    return output_node


def _get_final_output_image_input(output_node):
    return _get_socket(output_node.inputs, "Image")


def _configure_dilate_node(dilate_node, outline_thickness):
    size_socket = dilate_node.inputs.get("Size")
    type_socket = dilate_node.inputs.get("Type")

    if size_socket is not None:
        size_socket.default_value = outline_thickness

    if type_socket is not None:
        type_socket.default_value = "Steps"


def _configure_mask_node(mask_node, outline_color, background_color):
    background_socket = mask_node.inputs.get("Background")
    foreground_socket = mask_node.inputs.get("Foreground")
    factor_socket = mask_node.inputs.get("Factor")
    type_socket = mask_node.inputs.get("Type")

    if background_socket is not None:
        background_socket.default_value = background_color

    if foreground_socket is not None:
        foreground_socket.default_value = outline_color

    if factor_socket is not None:
        factor_socket.default_value = 1.0

    if type_socket is not None:
        type_socket.default_value = "Over"


def _configure_composite_node(composite_node):
    factor_socket = composite_node.inputs.get("Factor")
    type_socket = composite_node.inputs.get("Type")

    if factor_socket is not None:
        factor_socket.default_value = 1.0

    if type_socket is not None:
        type_socket.default_value = "Over"


def _create_outline_branch(
    node_tree,
    group_input_node,
    group_output_node,
    outline_thickness,
    outline_color,
    background_color,
    dilate_name,
    mask_name,
    composite_name,
    output_socket_name,
    location_y,
):
    image_output = _get_socket(group_input_node.outputs, "Image")
    alpha_output = _get_socket(group_input_node.outputs, "Alpha", 1)

    dilate_node = _get_or_create_node(
        node_tree,
        "CompositorNodeDilateErode",
        dilate_name,
    )
    dilate_node.location = (-360, location_y - 60)
    _configure_dilate_node(dilate_node, outline_thickness)

    mask_node = _get_or_create_node(
        node_tree,
        "CompositorNodeAlphaOver",
        mask_name,
    )
    mask_node.location = (-80, location_y)
    _configure_mask_node(mask_node, outline_color, background_color)

    composite_node = _get_or_create_node(
        node_tree,
        "CompositorNodeAlphaOver",
        composite_name,
    )
    composite_node.location = (220, location_y + 80)
    _configure_composite_node(composite_node)

    _replace_input_link(
        node_tree,
        _get_socket(dilate_node.inputs, "Mask"),
        alpha_output,
    )
    _replace_input_link(
        node_tree,
        _get_socket(mask_node.inputs, "Factor", 2),
        _get_socket(dilate_node.outputs, "Mask"),
    )
    _replace_input_link(
        node_tree,
        _get_socket(composite_node.inputs, "Background"),
        _get_socket(mask_node.outputs, "Image"),
    )
    _replace_input_link(
        node_tree,
        _get_socket(composite_node.inputs, "Foreground", 1),
        image_output,
    )
    _replace_input_link(
        node_tree,
        _get_socket(group_output_node.inputs, output_socket_name),
        _get_socket(composite_node.outputs, "Image"),
    )


def _ensure_outline_group(
    outline_thickness,
    viewport_outline_thickness,
    outline_color,
    background_color,
):
    group = bpy.data.node_groups.get(BPK_OUTLINE_GROUP_NAME)

    if group is None or group.bl_idname != "CompositorNodeTree":
        group = bpy.data.node_groups.new(
            BPK_OUTLINE_GROUP_NAME,
            "CompositorNodeTree",
        )

    group.nodes.clear()
    _ensure_group_socket(group, "Image", "INPUT")
    _ensure_group_socket(group, "Alpha", "INPUT", "NodeSocketFloat")
    _ensure_group_socket(group, "Image", "OUTPUT")
    _ensure_group_socket(group, "Viewport Image", "OUTPUT")

    group_input_node = group.nodes.new("NodeGroupInput")
    group_input_node.location = (-700, 40)

    group_output_node = group.nodes.new("NodeGroupOutput")
    group_output_node.location = (540, 40)

    _create_outline_branch(
        group,
        group_input_node,
        group_output_node,
        outline_thickness,
        outline_color,
        background_color,
        BPK_OUTLINE_DILATE_NODE_NAME,
        BPK_OUTLINE_MASK_NODE_NAME,
        BPK_OUTLINE_COMPOSITE_NODE_NAME,
        "Image",
        120,
    )
    _create_outline_branch(
        group,
        group_input_node,
        group_output_node,
        viewport_outline_thickness,
        outline_color,
        background_color,
        BPK_VIEWPORT_OUTLINE_DILATE_NODE_NAME,
        BPK_VIEWPORT_OUTLINE_MASK_NODE_NAME,
        BPK_VIEWPORT_OUTLINE_COMPOSITE_NODE_NAME,
        "Viewport Image",
        -220,
    )

    return group


def _route_final_image(node_tree, output_node, image_output):
    output_image_input = _get_final_output_image_input(output_node)
    _replace_input_link(node_tree, output_image_input, image_output)


def _route_viewport_preview_image(node_tree, image_output):
    viewport_group = node_tree.nodes.get(VIEWPORT_PIXEL_GROUP_NODE_NAME)

    if viewport_group is None:
        return

    viewport_image_input = _get_socket(viewport_group.inputs, "Image")
    _replace_input_link(node_tree, viewport_image_input, image_output)


def _setup_outline_nodes(scene, outline_thickness, outline_color, background_color):
    scene.render.film_transparent = True
    scene.render.image_settings.color_mode = "RGBA"

    node_tree = get_scene_compositor_tree(scene, create=True)

    if node_tree is None:
        raise RuntimeError("Could not create a compositor node tree.")

    render_layers_node = _ensure_render_layers_node(node_tree)
    output_node = _ensure_final_output_node(scene, node_tree)

    render_image_output = _get_socket(render_layers_node.outputs, "Image")
    render_alpha_output = _get_socket(render_layers_node.outputs, "Alpha", 1)
    addon_settings = scene.blender_pixel_kit_settings
    viewport_outline_thickness = get_viewport_outline_thickness(
        outline_thickness,
        addon_settings.viewport_preview_scale,
    )

    group = _ensure_outline_group(
        outline_thickness,
        viewport_outline_thickness,
        outline_color,
        background_color,
    )
    group_node = _get_or_create_node(
        node_tree,
        "CompositorNodeGroup",
        BPK_OUTLINE_GROUP_NODE_NAME,
    )
    group_node.node_tree = group
    group_node.location = (-120, 20)

    _replace_input_link(
        node_tree,
        _get_socket(group_node.inputs, "Image"),
        render_image_output,
    )
    _replace_input_link(
        node_tree,
        _get_socket(group_node.inputs, "Alpha", 1),
        render_alpha_output,
    )
    _route_final_image(
        node_tree,
        output_node,
        _get_socket(group_node.outputs, "Image"),
    )
    _route_viewport_preview_image(
        node_tree,
        _get_socket(group_node.outputs, "Viewport Image", 1),
    )


def _remove_outline_nodes(scene):
    node_tree = get_scene_compositor_tree(scene)

    if node_tree is None:
        return 0

    render_layers_node = _find_node_by_type(node_tree, "CompositorNodeRLayers")
    output_node = _ensure_final_output_node(scene, node_tree)
    removed_count = 0

    if render_layers_node is not None:
        render_image_output = _get_socket(render_layers_node.outputs, "Image")
        _route_final_image(node_tree, output_node, render_image_output)
        _route_viewport_preview_image(node_tree, render_image_output)

    for node_name in OUTLINE_NODE_NAMES:
        node = node_tree.nodes.get(node_name)

        if node is None:
            continue

        node_tree.nodes.remove(node)
        removed_count += 1

    group = bpy.data.node_groups.get(BPK_OUTLINE_GROUP_NAME)

    if group is not None and group.users == 0:
        bpy.data.node_groups.remove(group)

    return removed_count


class PIXEL_PREVIEW_OT_setup_outline(bpy.types.Operator):
    """Set up a compositor alpha outline."""

    bl_idname = "blender_pixel_kit.setup_outline"
    bl_label = "Set up Outline"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        addon_settings = context.scene.blender_pixel_kit_settings

        try:
            _setup_outline_nodes(
                context.scene,
                addon_settings.outline_thickness,
                addon_settings.outline_color,
                addon_settings.outline_background_color,
            )
        except RuntimeError as error:
            set_status(context, f"(>_<) {error}")
            self.report({"WARNING"}, str(error))
            return {"CANCELLED"}

        print("[Blender Pixel Kit] Compositor outline set up.")
        self.report({"INFO"}, "Outline set up.")
        set_status(context, "(^_^) Outline layer ready.")
        return {"FINISHED"}


class PIXEL_PREVIEW_OT_remove_outline(bpy.types.Operator):
    """Remove generated compositor outline nodes."""

    bl_idname = "blender_pixel_kit.remove_outline"
    bl_label = "Remove Outline"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        removed_count = _remove_outline_nodes(context.scene)

        print(
            "[Blender Pixel Kit] Removed outline node(s): "
            f"{removed_count}."
        )
        self.report({"INFO"}, f"Removed {removed_count} outline node(s).")
        set_status(context, "(._.) Outline removed.")
        return {"FINISHED"}


classes = (
    PIXEL_PREVIEW_OT_setup_outline,
    PIXEL_PREVIEW_OT_remove_outline,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
