import bpy

from ..utils.grid_images import attach_grid_background
from ..utils.grid_images import clear_grid_backgrounds
from ..utils.status import set_status
from ..utils.camera import apply_camera_projection
from ..utils.camera import apply_camera_transform
from .viewport_preview import _update_viewport_preview_resolution
from .viewport_preview import _viewport_preview_is_set_up


def _get_scene_resolution(context):
    addon_settings = context.scene.blender_pixel_kit_settings
    width = max(1, addon_settings.current_resolution_x)
    height = max(1, addon_settings.current_resolution_y)

    return width, height


def _resolution_label(width, height):
    return f"{width}x{height}"


def _create_camera(base_name):
    camera_data = bpy.data.cameras.new(base_name)
    camera_object = bpy.data.objects.new(base_name, camera_data)
    bpy.context.collection.objects.link(camera_object)

    return camera_object


def _get_active_camera(context):
    active_object = context.view_layer.objects.active

    if active_object is None or active_object.type != "CAMERA":
        return None

    return active_object


def _camera_type_from_name(camera_object):
    if camera_object.name.startswith("BPK Iso"):
        return "ISO"

    if camera_object.name.startswith("BPK Pixel"):
        return "PIXEL"

    return None


def _camera_base_name(camera_object, camera_type, label):
    current_name = camera_object.name

    if not (
        current_name.startswith("BPK Iso")
        or current_name.startswith("BPK Pixel")
    ):
        return None

    if camera_type == "ISO":
        return f"BPK Iso {label} Camera"

    return f"BPK Pixel {label} Camera"


def _update_camera_transform(camera_object, previous_camera_type, camera_type, distance, previous_distance):
    if previous_camera_type != camera_type:
        apply_camera_transform(camera_object, camera_type, distance)
        return

    if camera_type == "ISO":
        distance_delta = distance - previous_distance
        camera_object.location.x += distance_delta
        camera_object.location.y -= distance_delta
        camera_object.location.z += distance_delta
        return

    camera_object.location.y = -distance


def _rename_camera(camera_object, base_name):
    camera_object.name = base_name

    if camera_object.data is not None:
        camera_object.data.name = camera_object.name


def _finish_camera_setup(context, camera_object, width, height):
    addon_settings = context.scene.blender_pixel_kit_settings

    attach_grid_background(
        camera_object.data,
        width,
        height,
        addon_settings.grid_opacity,
    )

    context.scene.camera = camera_object
    camera_object.select_set(True)
    context.view_layer.objects.active = camera_object


def _create_front_camera(context):
    addon_settings = context.scene.blender_pixel_kit_settings
    width, height = _get_scene_resolution(context)
    label = _resolution_label(width, height)
    distance = addon_settings.iso_camera_distance
    camera_object = _create_camera(
        f"BPK Pixel {label} Camera"
    )

    apply_camera_transform(camera_object, "PIXEL", distance)
    apply_camera_projection(
        camera_object,
        addon_settings.camera_projection,
        addon_settings.camera_ortho_scale,
    )
    _finish_camera_setup(context, camera_object, width, height)

    print(
        "[Blender Pixel Kit] Pixel camera created: "
        f"{camera_object.name}, {label}, distance {distance:g}, "
        f"{addon_settings.camera_projection}."
    )

    return label, camera_object.name


def _create_iso_camera(context):
    addon_settings = context.scene.blender_pixel_kit_settings
    width, height = _get_scene_resolution(context)
    label = _resolution_label(width, height)
    distance = addon_settings.iso_camera_distance
    camera_object = _create_camera(
        f"BPK Iso {label} Camera"
    )

    apply_camera_transform(camera_object, "ISO", distance)
    apply_camera_projection(
        camera_object,
        addon_settings.camera_projection,
        addon_settings.camera_ortho_scale,
    )
    _finish_camera_setup(context, camera_object, width, height)

    print(
        "[Blender Pixel Kit] Isometric pixel camera created: "
        f"{camera_object.name}, {label}, distance {distance:g}, "
        f"{addon_settings.camera_projection}."
    )

    return label, camera_object.name


class PIXEL_PREVIEW_OT_set_camera_projection(bpy.types.Operator):
    """Set the projection type used by generated pixel cameras."""

    bl_idname = "blender_pixel_kit.set_camera_projection"
    bl_label = "Set Camera Projection"
    bl_options = {"REGISTER", "UNDO"}

    projection: bpy.props.EnumProperty(
        items=(
            ("ORTHO", "Orthographic", ""),
            ("PERSP", "Perspective", ""),
        ),
        default="ORTHO",
    )

    def execute(self, context):
        addon_settings = context.scene.blender_pixel_kit_settings
        addon_settings.camera_projection = self.projection

        set_status(context, "(^_^) Projection updated.")
        self.report({"INFO"}, f"Projection set to {self.projection}.")
        return {"FINISHED"}


class PIXEL_PREVIEW_OT_create_selected_pixel_camera(bpy.types.Operator):
    """Create the selected pixel camera type."""

    bl_idname = "blender_pixel_kit.create_selected_pixel_camera"
    bl_label = "Create Camera"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        addon_settings = context.scene.blender_pixel_kit_settings

        if addon_settings.camera_type == "ISO":
            label, camera_name = _create_iso_camera(context)
            set_status(context, "(^_^) Iso camera framed.")
            self.report({"INFO"}, f"Created {camera_name} ({label}).")
            return {"FINISHED"}

        label, camera_name = _create_front_camera(context)
        set_status(context, "(^_^) Pixel camera framed.")
        self.report({"INFO"}, f"Created {camera_name} ({label}).")
        return {"FINISHED"}


class PIXEL_PREVIEW_OT_update_selected_pixel_camera(bpy.types.Operator):
    """Update the selected camera grid and name for the scene resolution."""

    bl_idname = "blender_pixel_kit.update_selected_pixel_camera"
    bl_label = "Update Selected Camera"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        camera_object = _get_active_camera(context)

        if camera_object is None:
            set_status(context, "(o_o) Select a camera first.")
            self.report({"WARNING"}, "Select a camera to update.")
            return {"CANCELLED"}

        addon_settings = context.scene.blender_pixel_kit_settings
        width, height = _get_scene_resolution(context)
        label = _resolution_label(width, height)
        camera_type = addon_settings.camera_type
        previous_camera_type = _camera_type_from_name(camera_object)
        base_name = _camera_base_name(camera_object, camera_type, label)
        distance = addon_settings.iso_camera_distance
        previous_distance = addon_settings.last_camera_distance

        if base_name is not None:
            _rename_camera(camera_object, base_name)

        _update_camera_transform(
            camera_object,
            previous_camera_type,
            camera_type,
            distance,
            previous_distance,
        )
        apply_camera_projection(
            camera_object,
            addon_settings.camera_projection,
            addon_settings.camera_ortho_scale,
        )
        addon_settings.last_camera_distance = distance
        attach_grid_background(
            camera_object.data,
            width,
            height,
            addon_settings.grid_opacity,
        )

        context.scene.camera = camera_object
        preview_message = ""
        preview_updated = False

        if _viewport_preview_is_set_up(context.scene):
            try:
                preview_resolution, visible_camera_width, _offset_x, _offset_y = (
                    _update_viewport_preview_resolution(context)
                )
                preview_updated = True
                preview_message = (
                    f" Preview resolution set to {preview_resolution:.4f} "
                    f"from {visible_camera_width:.1f}px camera width."
                )
            except RuntimeError as error:
                preview_message = f" Preview resolution unchanged: {error}"
                print(
                    "[Blender Pixel Kit] Camera updated, but viewport preview "
                    f"resolution was not updated: {error}"
                )

        print(
            "[Blender Pixel Kit] Updated selected camera: "
            f"{camera_object.name}, {label} grid, distance {distance:g}, "
            f"{addon_settings.camera_projection}."
        )
        self.report(
            {"INFO"},
            f"Updated {camera_object.name} to {label}.{preview_message}",
        )
        if preview_updated:
            set_status(context, "(^o^) Camera and preview refreshed.")
        else:
            set_status(context, "(^o^) Camera grid refreshed.")
        return {"FINISHED"}


class PIXEL_PREVIEW_OT_create_front_pixel_camera(bpy.types.Operator):
    """Create a front-facing pixel camera for the scene resolution."""

    bl_idname = "blender_pixel_kit.create_front_pixel_camera"
    bl_label = "Create Front Camera"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        label, camera_name = _create_front_camera(context)
        set_status(context, "(^_^) Pixel camera framed.")
        self.report({"INFO"}, f"Created {camera_name} ({label}).")
        return {"FINISHED"}


class PIXEL_PREVIEW_OT_create_iso_pixel_camera(bpy.types.Operator):
    """Create an isometric pixel camera for the scene resolution."""

    bl_idname = "blender_pixel_kit.create_iso_pixel_camera"
    bl_label = "Create Isometric Camera"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        label, camera_name = _create_iso_camera(context)
        set_status(context, "(^_^) Iso camera framed.")
        self.report({"INFO"}, f"Created {camera_name} ({label}).")
        return {"FINISHED"}


class PIXEL_PREVIEW_OT_cleanup_grid_images(bpy.types.Operator):
    """Safely clear generated pixel grid camera backgrounds."""

    bl_idname = "blender_pixel_kit.cleanup_grid_images"
    bl_label = "Clear Grid Backgrounds"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        cleared_background_count = clear_grid_backgrounds()

        if context.screen is not None:
            for area in context.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()

        print(
            "[Blender Pixel Kit] Cleared pixel grid backgrounds: "
            f"{cleared_background_count}."
        )
        self.report(
            {"INFO"},
            f"Cleared {cleared_background_count} grid background(s).",
        )
        set_status(context, "(._.) Grid backgrounds cleared.")
        return {"FINISHED"}


classes = (
    PIXEL_PREVIEW_OT_set_camera_projection,
    PIXEL_PREVIEW_OT_create_selected_pixel_camera,
    PIXEL_PREVIEW_OT_update_selected_pixel_camera,
    PIXEL_PREVIEW_OT_create_front_pixel_camera,
    PIXEL_PREVIEW_OT_create_iso_pixel_camera,
    PIXEL_PREVIEW_OT_cleanup_grid_images,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
