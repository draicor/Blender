import bpy

from ..utils.status import set_status
from ..utils.viewport_display import set_render_preview_pixel_size
from ..utils.viewport_display import set_viewport_render_preview


def _apply_selected_resolution(scene):
    addon_settings = scene.blender_pixel_kit_settings

    if addon_settings.resolution_preset == "CUSTOM":
        width = max(1, addon_settings.custom_resolution_x)
        height = max(1, addon_settings.custom_resolution_y)
    else:
        width = int(addon_settings.resolution_preset)
        height = width
        addon_settings.custom_resolution_x = width
        addon_settings.custom_resolution_y = height

    scene.render.resolution_x = width
    scene.render.resolution_y = height
    addon_settings.current_resolution_x = width
    addon_settings.current_resolution_y = height

    return width, height


class PIXEL_PREVIEW_OT_apply_render_settings(bpy.types.Operator):
    """Apply basic render settings for crisp pixel-art output."""

    bl_idname = "blender_pixel_kit.apply_render_settings"
    bl_label = "Set up Render Settings"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene

        scene.render.engine = "BLENDER_EEVEE"
        scene.render.filter_size = 0.0
        scene.render.resolution_percentage = 100
        scene.view_settings.view_transform = "Standard"
        width, height = _apply_selected_resolution(scene)
        pixel_size_updated = set_render_preview_pixel_size(scene)
        updated_viewports = set_viewport_render_preview(context)

        print("[Blender Pixel Kit] Applied pixel render settings.")
        print("[Blender Pixel Kit] Engine: BLENDER_EEVEE")
        print("[Blender Pixel Kit] Filter Size: 0.0")
        print("[Blender Pixel Kit] Resolution Percentage: 100")
        print("[Blender Pixel Kit] View Transform: Standard")
        print(f"[Blender Pixel Kit] Resolution: {width} x {height}.")
        print(
            "[Blender Pixel Kit] Viewport Pixel Size: 1x "
            f"({'updated' if pixel_size_updated else 'unavailable'})."
        )
        print(
            "[Blender Pixel Kit] Viewport Compositor: Camera "
            f"({updated_viewports} viewport space(s))."
        )

        set_status(context, "(-_-) Render settings complete.")
        self.report({"INFO"}, "Pixel render settings applied.")
        return {"FINISHED"}


classes = (
    PIXEL_PREVIEW_OT_apply_render_settings,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
