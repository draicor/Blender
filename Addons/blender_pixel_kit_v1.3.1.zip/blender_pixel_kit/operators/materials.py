import bpy
from pathlib import Path
from bpy.app.handlers import persistent

from ..utils.status import set_status


DEFAULT_PALETTE_PATH = (
    Path(__file__).resolve().parents[1]
    / "assets"
    / "palettes"
    / "Pixel_Kit_Color_Palette_Default.png"
)

TOON_DITHER_GROUP_NAME = "BPK Toon Dither"
IMAGE_COLOR_SNAP_GROUP_NAME = "BPK Image Color Snap"
IMAGE_PIXEL_CELLS_GROUP_NAME = "BPK Image Pixel Cells"


def _set_node_input(node, input_name, value):
    socket = node.inputs.get(input_name)

    if socket is not None:
        socket.default_value = value


def _set_enum_if_available(data_block, property_name, value):
    if property_name in data_block.bl_rna.properties:
        try:
            setattr(data_block, property_name, value)
        except TypeError:
            pass


def _new_math_node(node_tree, operation, location, label=None, value_1=None):
    node = node_tree.nodes.new("ShaderNodeMath")
    node.operation = operation
    node.location = location

    if label is not None:
        node.label = label

    if value_1 is not None:
        node.inputs[1].default_value = value_1

    return node


def _new_vector_math_node(node_tree, operation, location, label=None):
    node = node_tree.nodes.new("ShaderNodeVectorMath")
    node.operation = operation
    node.location = location

    if label is not None:
        node.label = label

    return node


def _load_packed_image(image_path, color_space):
    image = bpy.data.images.load(str(image_path), check_existing=True)

    if hasattr(image, "colorspace_settings"):
        image.colorspace_settings.name = color_space

    if hasattr(image, "alpha_mode"):
        image.alpha_mode = "STRAIGHT"

    if image.packed_file is None:
        image.pack()

    return image


def _load_default_palette_image():
    return _load_packed_image(DEFAULT_PALETTE_PATH, "sRGB")


def _configure_toon_ramp(color_ramp_node):
    ramp = color_ramp_node.color_ramp
    ramp.interpolation = "CONSTANT"

    while len(ramp.elements) < 3:
        ramp.elements.new(1.0)

    while len(ramp.elements) > 3:
        ramp.elements.remove(ramp.elements[-1])

    ramp.elements[0].position = 0.0
    ramp.elements[0].color = (0.0, 0.0, 0.0, 1.0)
    ramp.elements[1].position = 0.333
    ramp.elements[1].color = (0.5, 0.5, 0.5, 1.0)
    ramp.elements[2].position = 0.666667
    ramp.elements[2].color = (1.0, 1.0, 1.0, 1.0)


def _clear_group_interface(node_group):
    for item in reversed(list(node_group.interface.items_tree)):
        if item.item_type == "SOCKET":
            node_group.interface.remove(item)


def _new_group_socket(node_group, name, in_out, socket_type):
    node_group.interface.new_socket(
        name=name,
        in_out=in_out,
        socket_type=socket_type,
    )


def _ensure_toon_dither_group():
    node_group = bpy.data.node_groups.get(TOON_DITHER_GROUP_NAME)

    if node_group is None:
        node_group = bpy.data.node_groups.new(TOON_DITHER_GROUP_NAME, "ShaderNodeTree")

    node_group.nodes.clear()
    _clear_group_interface(node_group)
    _new_group_socket(node_group, "Color", "INPUT", "NodeSocketColor")
    _new_group_socket(node_group, "Dither Px Scale", "INPUT", "NodeSocketFloat")
    _new_group_socket(node_group, "Factor", "OUTPUT", "NodeSocketFloat")

    input_node = node_group.nodes.new("NodeGroupInput")
    input_node.location = (-1280, 0)

    output_node = node_group.nodes.new("NodeGroupOutput")
    output_node.location = (1840, 0)

    lighting_node = node_group.nodes.new("ShaderNodeRGBToBW")
    lighting_node.label = "Lighting Value"
    lighting_node.location = (-1040, 120)

    texcoord_node = node_group.nodes.new("ShaderNodeTexCoord")
    texcoord_node.location = (-1040, -220)

    combine_scale_node = node_group.nodes.new("ShaderNodeCombineXYZ")
    combine_scale_node.label = "Cell Scale"
    combine_scale_node.location = (-800, -420)

    multiply_node = _new_vector_math_node(
        node_group,
        "MULTIPLY",
        (-800, -220),
        "Repeat Cells",
    )

    rotate_node = node_group.nodes.new("ShaderNodeVectorRotate")
    rotate_node.label = "Angle Screen"
    rotate_node.rotation_type = "Z_AXIS"
    rotate_node.location = (-600, -220)
    _set_node_input(rotate_node, "Angle", 0.785398)

    fraction_node = _new_vector_math_node(
        node_group,
        "FRACTION",
        (-400, -220),
        "Cell Fraction",
    )

    separate_cell_node = node_group.nodes.new("ShaderNodeSeparateXYZ")
    separate_cell_node.label = "Cell Coordinates"
    separate_cell_node.location = (-200, -220)

    center_x_node = _new_math_node(
        node_group,
        "SUBTRACT",
        (0, -160),
        "Center X",
        0.5,
    )
    center_y_node = _new_math_node(
        node_group,
        "SUBTRACT",
        (0, -300),
        "Center Y",
        0.5,
    )
    abs_x_node = _new_math_node(
        node_group,
        "ABSOLUTE",
        (200, -160),
        "Abs X",
    )
    abs_y_node = _new_math_node(
        node_group,
        "ABSOLUTE",
        (200, -300),
        "Abs Y",
    )
    square_metric_node = _new_math_node(
        node_group,
        "MAXIMUM",
        (400, -230),
        "Square From Center",
    )

    pattern_range_node = node_group.nodes.new("ShaderNodeMapRange")
    pattern_range_node.label = "Square Pattern"
    pattern_range_node.location = (200, 80)
    _set_node_input(pattern_range_node, "From Min", 0.0)
    _set_node_input(pattern_range_node, "From Max", 0.5)
    _set_node_input(pattern_range_node, "To Min", 0.0)
    _set_node_input(pattern_range_node, "To Max", 1.0)

    pattern_offset_node = _new_math_node(
        node_group,
        "SUBTRACT",
        (420, 80),
        "Centered Pattern",
        0.5,
    )
    dither_amount_node = _new_math_node(
        node_group,
        "MULTIPLY",
        (620, 80),
        "Dither Amount",
        0.16,
    )
    dithered_lighting_node = _new_math_node(
        node_group,
        "ADD",
        (820, 80),
        "Dithered Lighting",
    )
    clamp_dither_node = _new_math_node(
        node_group,
        "MINIMUM",
        (1020, 80),
        "Clamp High",
        1.0,
    )
    clamp_low_node = _new_math_node(
        node_group,
        "MAXIMUM",
        (1220, 80),
        "Clamp Low",
        0.0,
    )

    enabled_node = _new_math_node(
        node_group,
        "GREATER_THAN",
        (-1040, -520),
        "Dither Enabled",
        0.001,
    )
    inverted_enabled_node = _new_math_node(
        node_group,
        "SUBTRACT",
        (-800, -520),
        "Normal Mix",
    )
    inverted_enabled_node.inputs[0].default_value = 1.0

    normal_part_node = _new_math_node(
        node_group,
        "MULTIPLY",
        (1420, 140),
        "Normal Factor",
    )
    dither_part_node = _new_math_node(
        node_group,
        "MULTIPLY",
        (1420, -80),
        "Dither Factor",
    )
    output_mix_node = _new_math_node(
        node_group,
        "ADD",
        (1640, 0),
        "Final Factor",
    )

    node_group.links.new(input_node.outputs["Color"], lighting_node.inputs["Color"])
    node_group.links.new(texcoord_node.outputs["Window"], multiply_node.inputs[0])
    node_group.links.new(input_node.outputs["Dither Px Scale"], combine_scale_node.inputs["X"])
    node_group.links.new(input_node.outputs["Dither Px Scale"], combine_scale_node.inputs["Y"])
    node_group.links.new(combine_scale_node.outputs["Vector"], multiply_node.inputs[1])
    node_group.links.new(multiply_node.outputs["Vector"], rotate_node.inputs["Vector"])
    node_group.links.new(rotate_node.outputs["Vector"], fraction_node.inputs[0])
    node_group.links.new(fraction_node.outputs["Vector"], separate_cell_node.inputs["Vector"])
    node_group.links.new(separate_cell_node.outputs["X"], center_x_node.inputs[0])
    node_group.links.new(separate_cell_node.outputs["Y"], center_y_node.inputs[0])
    node_group.links.new(center_x_node.outputs["Value"], abs_x_node.inputs[0])
    node_group.links.new(center_y_node.outputs["Value"], abs_y_node.inputs[0])
    node_group.links.new(abs_x_node.outputs["Value"], square_metric_node.inputs[0])
    node_group.links.new(abs_y_node.outputs["Value"], square_metric_node.inputs[1])
    node_group.links.new(square_metric_node.outputs["Value"], pattern_range_node.inputs["Value"])
    node_group.links.new(pattern_range_node.outputs["Result"], pattern_offset_node.inputs[0])
    node_group.links.new(pattern_offset_node.outputs["Value"], dither_amount_node.inputs[0])
    node_group.links.new(lighting_node.outputs["Val"], dithered_lighting_node.inputs[0])
    node_group.links.new(dither_amount_node.outputs["Value"], dithered_lighting_node.inputs[1])
    node_group.links.new(dithered_lighting_node.outputs["Value"], clamp_dither_node.inputs[0])
    node_group.links.new(clamp_dither_node.outputs["Value"], clamp_low_node.inputs[0])
    node_group.links.new(input_node.outputs["Dither Px Scale"], enabled_node.inputs[0])
    node_group.links.new(enabled_node.outputs["Value"], inverted_enabled_node.inputs[1])
    node_group.links.new(lighting_node.outputs["Val"], normal_part_node.inputs[0])
    node_group.links.new(inverted_enabled_node.outputs["Value"], normal_part_node.inputs[1])
    node_group.links.new(clamp_low_node.outputs["Value"], dither_part_node.inputs[0])
    node_group.links.new(enabled_node.outputs["Value"], dither_part_node.inputs[1])
    node_group.links.new(normal_part_node.outputs["Value"], output_mix_node.inputs[0])
    node_group.links.new(dither_part_node.outputs["Value"], output_mix_node.inputs[1])
    node_group.links.new(output_mix_node.outputs["Value"], output_node.inputs["Factor"])

    return node_group


def _is_toon_dither_group(node_group):
    if node_group is None:
        return False

    if node_group.name.startswith(TOON_DITHER_GROUP_NAME):
        return True

    return any(
        node.label in {"Dot Threshold", "Square Dither Mask", "Dithered Lighting"}
        for node in node_group.nodes
    )


def _refresh_toon_dither_material_nodes():
    dither_nodes = []

    for material in bpy.data.materials:
        node_tree = material.node_tree

        if node_tree is None:
            continue

        for node in node_tree.nodes:
            if node.bl_idname != "ShaderNodeGroup":
                continue

            if node.label != "Dither" and not _is_toon_dither_group(node.node_tree):
                continue

            dither_scale = None

            if "Dither Px Scale" in node.inputs:
                dither_scale = node.inputs["Dither Px Scale"].default_value

            dither_nodes.append((node, dither_scale))

    toon_dither_group = _ensure_toon_dither_group()
    refreshed_count = 0

    for node, dither_scale in dither_nodes:
        node.node_tree = toon_dither_group

        if dither_scale is not None and "Dither Px Scale" in node.inputs:
            node.inputs["Dither Px Scale"].default_value = dither_scale

        refreshed_count += 1

    return refreshed_count


@persistent
def _refresh_toon_dither_after_load(_dummy):
    refreshed_count = _refresh_toon_dither_material_nodes()

    if refreshed_count:
        print(
            "[Blender Pixel Kit] Refreshed Toon Dither material node(s): "
            f"{refreshed_count}."
        )


def _ensure_image_color_snap_group():
    node_group = bpy.data.node_groups.get(IMAGE_COLOR_SNAP_GROUP_NAME)

    if node_group is None:
        node_group = bpy.data.node_groups.new(
            IMAGE_COLOR_SNAP_GROUP_NAME,
            "ShaderNodeTree",
        )

    node_group.nodes.clear()
    _clear_group_interface(node_group)
    _new_group_socket(node_group, "Color", "INPUT", "NodeSocketColor")
    _new_group_socket(node_group, "Color Steps", "INPUT", "NodeSocketFloat")
    _new_group_socket(node_group, "Color", "OUTPUT", "NodeSocketColor")

    input_node = node_group.nodes.new("NodeGroupInput")
    input_node.location = (-980, 0)

    output_node = node_group.nodes.new("NodeGroupOutput")
    output_node.location = (740, 0)

    separate_node = node_group.nodes.new("ShaderNodeSeparateColor")
    separate_node.location = (-700, 80)

    step_percent_node = _new_math_node(
        node_group,
        "DIVIDE",
        (-700, -160),
        "Step Percent",
        100.0,
    )
    safe_step_node = _new_math_node(
        node_group,
        "MAXIMUM",
        (-500, -160),
        "Safe Step",
        0.001,
    )

    snap_red_node = _new_math_node(
        node_group,
        "SNAP",
        (-220, 180),
        "Snap Red",
    )
    snap_green_node = _new_math_node(
        node_group,
        "SNAP",
        (-220, 20),
        "Snap Green",
    )
    snap_blue_node = _new_math_node(
        node_group,
        "SNAP",
        (-220, -140),
        "Snap Blue",
    )

    combine_node = node_group.nodes.new("ShaderNodeCombineColor")
    combine_node.location = (160, 60)

    node_group.links.new(input_node.outputs["Color"], separate_node.inputs["Color"])
    node_group.links.new(input_node.outputs["Color Steps"], step_percent_node.inputs[0])
    node_group.links.new(step_percent_node.outputs["Value"], safe_step_node.inputs[0])
    node_group.links.new(separate_node.outputs["Red"], snap_red_node.inputs[0])
    node_group.links.new(separate_node.outputs["Green"], snap_green_node.inputs[0])
    node_group.links.new(separate_node.outputs["Blue"], snap_blue_node.inputs[0])
    node_group.links.new(safe_step_node.outputs["Value"], snap_red_node.inputs[1])
    node_group.links.new(safe_step_node.outputs["Value"], snap_green_node.inputs[1])
    node_group.links.new(safe_step_node.outputs["Value"], snap_blue_node.inputs[1])
    node_group.links.new(snap_red_node.outputs["Value"], combine_node.inputs["Red"])
    node_group.links.new(snap_green_node.outputs["Value"], combine_node.inputs["Green"])
    node_group.links.new(snap_blue_node.outputs["Value"], combine_node.inputs["Blue"])
    node_group.links.new(combine_node.outputs["Color"], output_node.inputs["Color"])

    return node_group


def _ensure_image_pixel_cells_group():
    node_group = bpy.data.node_groups.get(IMAGE_PIXEL_CELLS_GROUP_NAME)

    if node_group is None:
        node_group = bpy.data.node_groups.new(
            IMAGE_PIXEL_CELLS_GROUP_NAME,
            "ShaderNodeTree",
        )

    node_group.nodes.clear()
    _clear_group_interface(node_group)
    _new_group_socket(node_group, "Vector", "INPUT", "NodeSocketVector")
    _new_group_socket(node_group, "Pixel Scale", "INPUT", "NodeSocketFloat")
    _new_group_socket(node_group, "Vector", "OUTPUT", "NodeSocketVector")

    input_node = node_group.nodes.new("NodeGroupInput")
    input_node.location = (-760, 0)

    output_node = node_group.nodes.new("NodeGroupOutput")
    output_node.location = (-80, 0)

    voronoi_node = node_group.nodes.new("ShaderNodeTexVoronoi")
    voronoi_node.label = "Pixel Cells"
    voronoi_node.location = (-420, 0)
    _set_enum_if_available(voronoi_node, "voronoi_dimensions", "3D")
    _set_enum_if_available(voronoi_node, "feature", "F1")
    _set_enum_if_available(voronoi_node, "distance", "EUCLIDEAN")
    _set_node_input(voronoi_node, "Detail", 0.0)
    _set_node_input(voronoi_node, "Roughness", 0.5)
    _set_node_input(voronoi_node, "Lacunarity", 2.0)
    _set_node_input(voronoi_node, "Randomness", 0.0)

    node_group.links.new(input_node.outputs["Vector"], voronoi_node.inputs["Vector"])
    node_group.links.new(input_node.outputs["Pixel Scale"], voronoi_node.inputs["Scale"])
    node_group.links.new(voronoi_node.outputs["Position"], output_node.inputs["Vector"])

    return node_group


def _create_flat_material():
    material = bpy.data.materials.new("BPK Flat")
    material.use_nodes = True

    node_tree = material.node_tree
    node_tree.nodes.clear()

    output_node = node_tree.nodes.new("ShaderNodeOutputMaterial")
    output_node.location = (300, 0)

    color_node = node_tree.nodes.new("ShaderNodeRGB")
    color_node.label = "Color"
    color_node.location = (-120, 0)
    color_node.outputs["Color"].default_value = (0.8, 0.8, 0.8, 1.0)

    node_tree.links.new(
        color_node.outputs["Color"],
        output_node.inputs["Surface"],
    )

    return material


def _create_flat_uv_material():
    material = bpy.data.materials.new("BPK Flat UV")
    material.use_nodes = True

    node_tree = material.node_tree
    node_tree.nodes.clear()

    texcoord_node = node_tree.nodes.new("ShaderNodeTexCoord")
    texcoord_node.location = (-640, 0)

    image_node = node_tree.nodes.new("ShaderNodeTexImage")
    image_node.location = (-300, 0)
    image_node.image = _load_default_palette_image()
    _set_enum_if_available(image_node, "interpolation", "Closest")
    _set_enum_if_available(image_node, "projection", "FLAT")
    _set_enum_if_available(image_node, "extension", "REPEAT")

    output_node = node_tree.nodes.new("ShaderNodeOutputMaterial")
    output_node.location = (220, 0)

    node_tree.links.new(
        texcoord_node.outputs["UV"],
        image_node.inputs["Vector"],
    )
    node_tree.links.new(
        image_node.outputs["Color"],
        output_node.inputs["Surface"],
    )

    return material


def _create_toon_material():
    material = bpy.data.materials.new("BPK Toon")
    material.use_nodes = True

    node_tree = material.node_tree
    node_tree.nodes.clear()

    principled_node = node_tree.nodes.new("ShaderNodeBsdfPrincipled")
    principled_node.location = (-760, 0)
    _set_node_input(principled_node, "Base Color", (0.5, 0.5, 0.5, 1.0))
    _set_node_input(principled_node, "Metallic", 0.0)
    _set_node_input(principled_node, "Roughness", 0.5)
    _set_node_input(principled_node, "Alpha", 1.0)

    shader_to_rgb_node = node_tree.nodes.new("ShaderNodeShaderToRGB")
    shader_to_rgb_node.location = (-420, 0)

    dither_node = node_tree.nodes.new("ShaderNodeGroup")
    dither_node.label = "Dither"
    dither_node.location = (-100, 0)
    dither_node.node_tree = _ensure_toon_dither_group()
    dither_node.width = 220
    dither_node.inputs["Dither Px Scale"].default_value = 0.0

    color_ramp_node = node_tree.nodes.new("ShaderNodeValToRGB")
    color_ramp_node.location = (220, 0)
    _configure_toon_ramp(color_ramp_node)

    output_node = node_tree.nodes.new("ShaderNodeOutputMaterial")
    output_node.location = (620, 0)

    node_tree.links.new(
        principled_node.outputs["BSDF"],
        shader_to_rgb_node.inputs["Shader"],
    )
    node_tree.links.new(
        shader_to_rgb_node.outputs["Color"],
        dither_node.inputs["Color"],
    )
    node_tree.links.new(
        dither_node.outputs["Factor"],
        color_ramp_node.inputs["Fac"],
    )
    node_tree.links.new(
        color_ramp_node.outputs["Color"],
        output_node.inputs["Surface"],
    )

    return material


def _create_image_pixel_material():
    material = bpy.data.materials.new("BPK Image to Pixel")
    material.use_nodes = True

    node_tree = material.node_tree
    node_tree.nodes.clear()

    texcoord_node = node_tree.nodes.new("ShaderNodeTexCoord")
    texcoord_node.location = (-980, 0)

    cells_node = node_tree.nodes.new("ShaderNodeGroup")
    cells_node.label = "Pixel Cells"
    cells_node.location = (-700, 0)
    cells_node.node_tree = _ensure_image_pixel_cells_group()
    cells_node.width = 210
    cells_node.inputs["Pixel Scale"].default_value = 128.0

    image_node = node_tree.nodes.new("ShaderNodeTexImage")
    image_node.label = "Base Color"
    image_node.location = (-300, 0)
    _set_enum_if_available(image_node, "interpolation", "Closest")
    _set_enum_if_available(image_node, "projection", "FLAT")
    _set_enum_if_available(image_node, "extension", "REPEAT")

    snap_node = node_tree.nodes.new("ShaderNodeGroup")
    snap_node.label = "Color Snap"
    snap_node.location = (40, 0)
    snap_node.node_tree = _ensure_image_color_snap_group()
    snap_node.width = 210
    snap_node.inputs["Color Steps"].default_value = 0.0

    output_node = node_tree.nodes.new("ShaderNodeOutputMaterial")
    output_node.location = (380, 0)

    node_tree.links.new(
        texcoord_node.outputs["UV"],
        cells_node.inputs["Vector"],
    )
    node_tree.links.new(
        cells_node.outputs["Vector"],
        image_node.inputs["Vector"],
    )
    node_tree.links.new(
        image_node.outputs["Color"],
        snap_node.inputs["Color"],
    )
    node_tree.links.new(
        snap_node.outputs["Color"],
        output_node.inputs["Surface"],
    )

    return material


def _get_selected_material_targets(context):
    return [
        obj
        for obj in context.selected_objects
        if hasattr(obj.data, "materials")
    ]


def _assign_material_to_object(obj, material, assignment_mode):
    material_slots = obj.data.materials

    if assignment_mode == "REPLACE_ACTIVE":
        if not material_slots:
            material_slots.append(material)
            obj.active_material_index = len(material_slots) - 1
            return True

        active_index = min(obj.active_material_index, len(material_slots) - 1)
        material_slots[active_index] = material
        obj.active_material_index = active_index
        return True

    material_slots.append(material)
    obj.active_material_index = len(material_slots) - 1
    return True


def _assign_material_to_selection(targets, material, assignment_mode):
    assigned_count = 0
    skipped_count = 0

    for obj in targets:
        assigned = _assign_material_to_object(obj, material, assignment_mode)

        if assigned:
            assigned_count += 1
        else:
            skipped_count += 1

    return assigned_count, skipped_count


class PIXEL_PREVIEW_OT_create_pixel_material(bpy.types.Operator):
    """Create and assign a pixel material."""

    bl_idname = "blender_pixel_kit.create_pixel_material"
    bl_label = "Create Material"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        addon_settings = context.scene.blender_pixel_kit_settings
        targets = _get_selected_material_targets(context)

        if not targets:
            set_status(context, "(o_o) Select a material object first.")
            self.report(
                {"WARNING"},
                "Select an object that can receive materials.",
            )
            return {"CANCELLED"}

        if addon_settings.material_type == "FLAT":
            material = _create_flat_material()
        elif addon_settings.material_type == "FLAT_UV":
            material = _create_flat_uv_material()
        elif addon_settings.material_type == "TOON":
            material = _create_toon_material()
        elif addon_settings.material_type == "IMAGE_PIXEL":
            material = _create_image_pixel_material()
        else:
            material_label = addon_settings.bl_rna.properties[
                "material_type"
            ].enum_items[addon_settings.material_type].name

            self.report(
                {"INFO"},
                f"{material_label} material setup is coming next.",
            )
            print(
                "[Blender Pixel Kit] Material placeholder selected: "
                f"{addon_settings.material_type}, "
                f"{addon_settings.material_assignment_mode}."
            )
            set_status(context, "(._.) That material is coming soon.")
            return {"FINISHED"}

        assigned_count, skipped_count = _assign_material_to_selection(
            targets,
            material,
            addon_settings.material_assignment_mode,
        )

        report_message = (
            f"Created {material.name} and assigned to {assigned_count} object(s)."
        )

        if skipped_count > 0:
            report_message += f" Skipped {skipped_count} without material slots."

        self.report(
            {"INFO"},
            report_message,
        )
        print(
            "[Blender Pixel Kit] Material created: "
            f"{material.name}, assigned to {assigned_count} object(s), "
            f"skipped {skipped_count}, "
            f"{addon_settings.material_assignment_mode}."
        )
        set_status(context, f"(*^_^*) {material.name} ready.")
        return {"FINISHED"}


classes = (
    PIXEL_PREVIEW_OT_create_pixel_material,
)


def register():
    if _refresh_toon_dither_after_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_refresh_toon_dither_after_load)

    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    if _refresh_toon_dither_after_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_refresh_toon_dither_after_load)

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
