import bpy

from ..utils.constants import PANEL_CATEGORY
from ..utils.constants import PANEL_LABEL
from ..utils.viewport_display import viewport_render_preview_is_ready


PARENT_PANEL_ID = "PIXEL_PREVIEW_PT_pixel_kit"
RENDER_PANEL_ID = "PIXEL_PREVIEW_PT_render"
STYLE_PANEL_ID = "PIXEL_PREVIEW_PT_style"


def _draw_header(layout, context):
    header_box = layout.box()
    status_row = header_box.row()
    status_row.alignment = "LEFT"
    status_row.label(text=context.scene.blender_pixel_kit_settings.status_message)


def _scene_render_is_ready(context):
    scene = context.scene
    pixel_size_ready = (
        not hasattr(scene.render, "preview_pixel_size")
        or scene.render.preview_pixel_size == "1"
    )

    return (
        scene.render.engine == "BLENDER_EEVEE"
        and scene.render.filter_size == 0.0
        and scene.render.resolution_percentage == 100
        and scene.view_settings.view_transform == "Standard"
        and pixel_size_ready
        and viewport_render_preview_is_ready(context)
    )


class PIXEL_PREVIEW_PT_pixel_kit(bpy.types.Panel):
    bl_idname = PARENT_PANEL_ID
    bl_label = PANEL_LABEL
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = PANEL_CATEGORY

    def draw(self, context):
        _draw_header(self.layout, context)


class PIXEL_PREVIEW_PT_render(bpy.types.Panel):
    bl_idname = RENDER_PANEL_ID
    bl_label = "Render"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = PANEL_CATEGORY
    bl_parent_id = PARENT_PANEL_ID

    def draw(self, context):
        pass


class PIXEL_PREVIEW_PT_style(bpy.types.Panel):
    bl_idname = STYLE_PANEL_ID
    bl_label = "Style"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = PANEL_CATEGORY
    bl_parent_id = PARENT_PANEL_ID

    def draw(self, context):
        pass


class PIXEL_PREVIEW_PT_render_settings(bpy.types.Panel):
    bl_idname = "PIXEL_PREVIEW_PT_render_settings"
    bl_label = "Render Settings"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = PANEL_CATEGORY
    bl_parent_id = RENDER_PANEL_ID
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        addon_settings = scene.blender_pixel_kit_settings

        render_is_ready = _scene_render_is_ready(context)
        button_label = (
            "Render Settings Complete"
            if render_is_ready
            else "Set up Render Settings"
        )

        setup_row = layout.row()
        setup_row.enabled = not render_is_ready
        setup_row.operator(
            "blender_pixel_kit.apply_render_settings",
            text=button_label,
        )

        layout.prop(addon_settings, "resolution_preset", text="")

        if addon_settings.resolution_preset == "CUSTOM":
            custom_row = layout.row(align=True)
            custom_row.prop(addon_settings, "custom_resolution_x", text="X px")
            custom_row.prop(addon_settings, "custom_resolution_y", text="Y px")

        current_row = layout.row()
        current_row.label(
            text=(
                f"Current: {addon_settings.current_resolution_x} "
                f"x {addon_settings.current_resolution_y} px"
            )
        )


class PIXEL_PREVIEW_PT_pixel_cameras(bpy.types.Panel):
    bl_idname = "PIXEL_PREVIEW_PT_pixel_cameras"
    bl_label = "Cameras"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = PANEL_CATEGORY
    bl_parent_id = RENDER_PANEL_ID
    bl_order = 1

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        addon_settings = scene.blender_pixel_kit_settings

        layout.prop(addon_settings, "camera_type", text="")

        layout.label(text="Projection")
        projection_row = layout.row(align=True)
        ortho_button = projection_row.operator(
            "blender_pixel_kit.set_camera_projection",
            text="Orthographic",
            depress=addon_settings.camera_projection == "ORTHO",
        )
        ortho_button.projection = "ORTHO"

        persp_button = projection_row.operator(
            "blender_pixel_kit.set_camera_projection",
            text="Perspective",
            depress=addon_settings.camera_projection == "PERSP",
        )
        persp_button.projection = "PERSP"

        layout.prop(addon_settings, "iso_camera_distance", text="Distance")
        layout.prop(addon_settings, "camera_ortho_scale")
        layout.operator("blender_pixel_kit.create_selected_pixel_camera")
        layout.operator("blender_pixel_kit.update_selected_pixel_camera")

        layout.label(text="Grid")
        layout.prop(addon_settings, "grid_opacity")
        layout.operator("blender_pixel_kit.cleanup_grid_images")


class PIXEL_PREVIEW_PT_viewport_preview(bpy.types.Panel):
    bl_idname = "PIXEL_PREVIEW_PT_viewport_preview"
    bl_label = "Viewport Preview"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = PANEL_CATEGORY
    bl_parent_id = RENDER_PANEL_ID
    bl_order = 2

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        addon_settings = scene.blender_pixel_kit_settings

        layout.operator("blender_pixel_kit.update_viewport_preview_resolution")
        layout.prop(addon_settings, "viewport_preview_scale")
        offset_row = layout.row(align=True)
        offset_row.prop(addon_settings, "viewport_preview_offset_x", text="X")
        offset_row.prop(addon_settings, "viewport_preview_offset_y", text="Y")
        layout.operator("blender_pixel_kit.setup_viewport_pixel_preview")
        layout.operator("blender_pixel_kit.remove_viewport_pixel_preview")
        layout.operator("blender_pixel_kit.toggle_viewport_display")


class PIXEL_PREVIEW_PT_outlines(bpy.types.Panel):
    bl_idname = "PIXEL_PREVIEW_PT_outlines"
    bl_label = "Outlines"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = PANEL_CATEGORY
    bl_parent_id = STYLE_PANEL_ID
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        addon_settings = scene.blender_pixel_kit_settings

        layout.prop(addon_settings, "outline_thickness")
        layout.prop(addon_settings, "outline_color")
        layout.prop(addon_settings, "outline_background_color")
        layout.operator("blender_pixel_kit.setup_outline")
        layout.operator("blender_pixel_kit.remove_outline")


class PIXEL_PREVIEW_PT_materials(bpy.types.Panel):
    bl_idname = "PIXEL_PREVIEW_PT_materials"
    bl_label = "Materials"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = PANEL_CATEGORY
    bl_parent_id = STYLE_PANEL_ID
    bl_order = 1

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        addon_settings = scene.blender_pixel_kit_settings

        layout.prop(addon_settings, "material_type", text="")
        layout.prop(addon_settings, "material_assignment_mode", text="")
        layout.operator("blender_pixel_kit.create_pixel_material")


classes = (
    PIXEL_PREVIEW_PT_pixel_kit,
    PIXEL_PREVIEW_PT_render,
    PIXEL_PREVIEW_PT_style,
    PIXEL_PREVIEW_PT_render_settings,
    PIXEL_PREVIEW_PT_pixel_cameras,
    PIXEL_PREVIEW_PT_viewport_preview,
    PIXEL_PREVIEW_PT_outlines,
    PIXEL_PREVIEW_PT_materials,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
