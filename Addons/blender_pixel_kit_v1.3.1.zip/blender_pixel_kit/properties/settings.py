import bpy

from ..utils.camera import get_camera_type
from ..utils.grid_images import set_grid_background_opacity
from ..utils.outline import apply_outline_settings_to_tree
from ..utils.status import DEFAULT_STATUS_MESSAGE
from ..utils.status import set_status
from ..utils.viewport_preview import set_viewport_pixel_transform
from ..utils.viewport_preview import get_scene_compositor_tree


DEFAULT_RESOLUTION = 64


def apply_resolution_preset(self, context):
    if context is None:
        return

    if self.resolution_preset == "CUSTOM":
        print("[Blender Pixel Kit] Custom resolution mode selected.")
        return

    scene = context.scene
    size = int(self.resolution_preset)

    scene.render.resolution_x = size
    scene.render.resolution_y = size

    self.current_resolution_x = size
    self.current_resolution_y = size
    self.custom_resolution_x = size
    self.custom_resolution_y = size

    set_status(context, f"(^_^) Scene set to {size} x {size} px.")
    print(f"[Blender Pixel Kit] Preset resolution applied: {size} x {size}.")


def apply_custom_resolution(self, context):
    if context is None or self.resolution_preset != "CUSTOM":
        return

    scene = context.scene
    width = max(1, self.custom_resolution_x)
    height = max(1, self.custom_resolution_y)

    scene.render.resolution_x = width
    scene.render.resolution_y = height

    self.current_resolution_x = width
    self.current_resolution_y = height

    set_status(context, f"(^_^) Scene set to {width} x {height} px.")
    print(f"[Blender Pixel Kit] Custom resolution applied: {width} x {height}.")


def update_grid_opacity(self, context):
    if context is None:
        return

    updated_count = set_grid_background_opacity(self.grid_opacity)
    set_status(context, "(._.) Grid opacity adjusted.")
    print(
        "[Blender Pixel Kit] Updated grid background opacity on "
        f"{updated_count} camera background(s)."
    )


def update_viewport_preview_scale(self, context):
    if context is None:
        return

    updated = set_viewport_pixel_transform(
        context.scene,
        self.viewport_preview_scale,
        self.viewport_preview_offset_x,
        self.viewport_preview_offset_y,
    )

    if updated:
        set_status(context, "(^_^) Preview pixels adjusted.")
        print(
            "[Blender Pixel Kit] Updated viewport preview scale: "
            f"{self.viewport_preview_scale:g}."
        )

    update_outline_settings(self, context)


def update_viewport_preview_offset(self, context):
    if context is None:
        return

    updated = set_viewport_pixel_transform(
        context.scene,
        self.viewport_preview_scale,
        self.viewport_preview_offset_x,
        self.viewport_preview_offset_y,
    )

    if updated:
        set_status(context, "(^_^) Preview offset adjusted.")
        print(
            "[Blender Pixel Kit] Updated viewport preview offset: "
            f"{self.viewport_preview_offset_x:g}, "
            f"{self.viewport_preview_offset_y:g}."
        )


def update_outline_settings(self, context):
    if context is None:
        return

    node_tree = get_scene_compositor_tree(context.scene)

    if node_tree is None:
        return

    updated = apply_outline_settings_to_tree(
        node_tree,
        self.outline_thickness,
        self.outline_color,
        self.outline_background_color,
        self.viewport_preview_scale,
    )

    if updated:
        set_status(context, "(^_^) Outline settings updated.")
        print("[Blender Pixel Kit] Updated outline settings.")


def _get_active_camera(context):
    if context is None:
        return None

    active_object = context.view_layer.objects.active

    if active_object is None or active_object.type != "CAMERA":
        return None

    return active_object


def update_selected_camera_distance(self, context):
    camera_object = _get_active_camera(context)

    if camera_object is None:
        return

    camera_type = get_camera_type(self, camera_object)

    if camera_type == "ISO":
        distance_delta = self.iso_camera_distance - self.last_camera_distance
        camera_object.location.x += distance_delta
        camera_object.location.y -= distance_delta
        camera_object.location.z += distance_delta
    else:
        camera_object.location.y = -self.iso_camera_distance

    self.last_camera_distance = self.iso_camera_distance
    set_status(context, "(^_^) Camera distance adjusted.")
    print(
        "[Blender Pixel Kit] Live camera distance adjusted: "
        f"{camera_object.name}, distance {self.iso_camera_distance:g}."
    )


def update_selected_camera_ortho_scale(self, context):
    camera_object = _get_active_camera(context)

    if camera_object is None or camera_object.data.type != "ORTHO":
        return

    camera_object.data.ortho_scale = self.camera_ortho_scale

    set_status(context, "(^_^) Orthographic scale adjusted.")
    print(
        "[Blender Pixel Kit] Live camera orthographic scale adjusted: "
        f"{camera_object.name}, ortho scale {self.camera_ortho_scale:g}."
    )


class PixelPreviewSettings(bpy.types.PropertyGroup):
    status_message: bpy.props.StringProperty(
        name="Status Message",
        description="Small Pixel Kit header status message.",
        default=DEFAULT_STATUS_MESSAGE,
    )

    resolution_preset: bpy.props.EnumProperty(
        name="Resolution",
        description="Scene render resolution preset.",
        items=(
            ("16", "16 px", "16 x 16 px"),
            ("32", "32 px", "32 x 32 px"),
            ("64", "64 px", "64 x 64 px"),
            ("128", "128 px", "128 x 128 px"),
            ("256", "256 px", "256 x 256 px"),
            ("CUSTOM", "Custom", "Use a custom render resolution"),
        ),
        default=str(DEFAULT_RESOLUTION),
        update=apply_resolution_preset,
    )

    custom_resolution_x: bpy.props.IntProperty(
        name="Custom Resolution X",
        description="Custom horizontal render resolution.",
        default=DEFAULT_RESOLUTION,
        min=1,
        update=apply_custom_resolution,
    )

    custom_resolution_y: bpy.props.IntProperty(
        name="Custom Resolution Y",
        description="Custom vertical render resolution.",
        default=DEFAULT_RESOLUTION,
        min=1,
        update=apply_custom_resolution,
    )

    current_resolution_x: bpy.props.IntProperty(
        name="Current Resolution X",
        description="Stored current horizontal render resolution.",
        default=DEFAULT_RESOLUTION,
    )

    current_resolution_y: bpy.props.IntProperty(
        name="Current Resolution Y",
        description="Stored current vertical render resolution.",
        default=DEFAULT_RESOLUTION,
    )

    camera_projection: bpy.props.EnumProperty(
        name="Projection",
        description="Projection type for generated pixel cameras.",
        items=(
            ("ORTHO", "Orthographic", "Create orthographic pixel cameras"),
            ("PERSP", "Perspective", "Create perspective pixel cameras"),
        ),
        default="ORTHO",
    )

    camera_type: bpy.props.EnumProperty(
        name="Camera Type",
        description="Type of pixel camera to create.",
        items=(
            ("PIXEL", "Pixel Camera", "Create a front-facing pixel camera"),
            ("ISO", "Isometric Camera", "Create an isometric pixel camera"),
        ),
        default="PIXEL",
    )

    iso_camera_distance: bpy.props.FloatProperty(
        name="Camera Distance",
        description="Distance value used for generated camera location.",
        default=12.0,
        min=0.001,
        unit="LENGTH",
        update=update_selected_camera_distance,
    )

    camera_ortho_scale: bpy.props.FloatProperty(
        name="Orthographic Scale",
        description="Orthographic scale used for generated pixel cameras.",
        default=5.0,
        min=0.001,
        update=update_selected_camera_ortho_scale,
    )

    last_camera_distance: bpy.props.FloatProperty(
        name="Last Camera Distance",
        description="Internal value used to apply live camera distance deltas.",
        default=12.0,
        options={"HIDDEN"},
    )

    grid_opacity: bpy.props.FloatProperty(
        name="Grid Opacity",
        description="Opacity of generated camera grid backgrounds.",
        default=0.35,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
        update=update_grid_opacity,
    )

    viewport_preview_scale: bpy.props.FloatProperty(
        name="Preview Resolution",
        description="Viewer-only compositor preview resolution. Lower values look chunkier.",
        default=0.25,
        min=0.001,
        max=1.0,
        subtype="FACTOR",
        update=update_viewport_preview_scale,
    )

    viewport_preview_offset_x: bpy.props.FloatProperty(
        name="Preview Offset X",
        description="Small horizontal nudge for aligning the viewport preview grid.",
        default=0.0,
        soft_min=-32.0,
        soft_max=32.0,
        update=update_viewport_preview_offset,
    )

    viewport_preview_offset_y: bpy.props.FloatProperty(
        name="Preview Offset Y",
        description="Small vertical nudge for aligning the viewport preview grid.",
        default=0.0,
        soft_min=-32.0,
        soft_max=32.0,
        update=update_viewport_preview_offset,
    )

    outline_thickness: bpy.props.IntProperty(
        name="Line Thickness",
        description="Pixel outline thickness used by the compositor outline.",
        default=2,
        min=0,
        max=128,
        update=update_outline_settings,
    )

    outline_color: bpy.props.FloatVectorProperty(
        name="Line Color",
        description="Pixel outline color.",
        subtype="COLOR",
        size=4,
        min=0.0,
        max=1.0,
        default=(0.0, 0.0, 0.0, 1.0),
        update=update_outline_settings,
    )

    outline_background_color: bpy.props.FloatVectorProperty(
        name="Background Color",
        description="Background color composited behind the generated outline.",
        subtype="COLOR",
        size=4,
        min=0.0,
        max=1.0,
        default=(0.0, 0.0, 0.0, 0.0),
        update=update_outline_settings,
    )

    material_type: bpy.props.EnumProperty(
        name="Material Type",
        description="Pixel material type to create.",
        items=(
            ("FLAT", "Flat", "Create a flat color material"),
            ("FLAT_UV", "Flat UV", "Create a palette UV material"),
            ("TOON", "Toon", "Create a toon material"),
            ("IMAGE_PIXEL", "Image to Pixel", "Create an image pixelation material"),
        ),
        default="FLAT",
    )

    material_assignment_mode: bpy.props.EnumProperty(
        name="Assignment",
        description="How the created material should be assigned to selected objects.",
        items=(
            ("ADD_SLOT", "Add New Slot", "Add the material to a new material slot"),
            ("REPLACE_ACTIVE", "Replace Active", "Replace the active material slot"),
        ),
        default="ADD_SLOT",
    )

classes = (
    PixelPreviewSettings,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.blender_pixel_kit_settings = bpy.props.PointerProperty(
        type=PixelPreviewSettings
    )


def unregister():
    if hasattr(bpy.types.Scene, "blender_pixel_kit_settings"):
        del bpy.types.Scene.blender_pixel_kit_settings

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
