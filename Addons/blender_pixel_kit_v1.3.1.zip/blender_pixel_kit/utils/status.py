DEFAULT_STATUS_MESSAGE = "(^_^) Hi, I'm Pixie."


def _set_scene_status(scene, message):
    if scene is None or not hasattr(scene, "blender_pixel_kit_settings"):
        return False

    scene.blender_pixel_kit_settings.status_message = message
    return True


def set_status(context, message):
    if context is None:
        return

    scene = getattr(context, "scene", None)

    if scene is None:
        return

    _set_scene_status(scene, message)
