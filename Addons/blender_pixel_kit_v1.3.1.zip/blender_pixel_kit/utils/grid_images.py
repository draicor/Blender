import bpy


GRID_IMAGE_PREFIX = "BPK Pixel Grid"
GRID_TEXTURE_MAX_SIZE = 1024


def _grid_image_name(width, height):
    return f"{GRID_IMAGE_PREFIX} {width}x{height}"


def _grid_image_dimensions(width, height):
    scale = max(1, min(GRID_TEXTURE_MAX_SIZE // width, GRID_TEXTURE_MAX_SIZE // height))

    return width * scale, height * scale, scale


def get_or_create_grid_image(width, height):
    name = _grid_image_name(width, height)
    image_width, image_height, cell_size = _grid_image_dimensions(width, height)
    image = bpy.data.images.get(name)

    if image is not None and tuple(image.size) == (image_width, image_height):
        return image

    if image is None:
        image = bpy.data.images.new(
            name=name,
            width=image_width,
            height=image_height,
            alpha=True,
            float_buffer=False,
        )
    else:
        image.scale(image_width, image_height)

    pixels = [0.0] * (image_width * image_height * 4)

    for y in range(image_height):
        for x in range(image_width):
            is_major_line = x % cell_size == 0 or y % cell_size == 0
            is_border = (
                x == image_width - 1
                or y == image_height - 1
            )

            if not is_major_line and not is_border:
                continue

            index = (y * image_width + x) * 4
            pixels[index] = 1.0
            pixels[index + 1] = 1.0
            pixels[index + 2] = 1.0
            pixels[index + 3] = 0.4 if not is_border else 0.7

    image.pixels.foreach_set(pixels)
    image.pack()

    return image


def attach_grid_background(camera_data, width, height, opacity):
    image = get_or_create_grid_image(width, height)

    camera_data.show_background_images = True

    while len(camera_data.background_images) > 0:
        camera_data.background_images.remove(camera_data.background_images[0])

    background = camera_data.background_images.new()
    background.image = image
    background.alpha = opacity
    background.frame_method = "FIT"

    if hasattr(background, "display_depth"):
        background.display_depth = "FRONT"

    return image


def is_grid_image(image):
    return image.name.startswith(GRID_IMAGE_PREFIX)


def clear_grid_backgrounds():
    cleared_background_count = 0

    for camera in bpy.data.cameras:
        for background in list(camera.background_images):
            if background.image is None or not is_grid_image(background.image):
                continue

            background.image = None
            camera.background_images.remove(background)
            cleared_background_count += 1

        if len(camera.background_images) == 0:
            camera.show_background_images = False

        camera.update_tag()

    return cleared_background_count


def set_grid_background_opacity(opacity):
    updated_count = 0

    for camera in bpy.data.cameras:
        for background in camera.background_images:
            if background.image is None or not is_grid_image(background.image):
                continue

            background.alpha = opacity
            updated_count += 1

    return updated_count
