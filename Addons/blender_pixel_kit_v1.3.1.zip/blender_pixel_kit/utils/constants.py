PANEL_CATEGORY = "Pixel Kit"
PANEL_LABEL = "Pixel Kit"
