BPK_OUTLINE_GROUP_NAME = "BPK Outline"
BPK_OUTLINE_GROUP_NODE_NAME = "BPK Outline"
BPK_OUTLINE_DILATE_NODE_NAME = "BPK Outline Dilate"
BPK_OUTLINE_MASK_NODE_NAME = "BPK Outline Mask"
BPK_OUTLINE_COMPOSITE_NODE_NAME = "BPK Outline Composite"
BPK_VIEWPORT_OUTLINE_DILATE_NODE_NAME = "BPK Viewport Outline Dilate"
BPK_VIEWPORT_OUTLINE_MASK_NODE_NAME = "BPK Viewport Outline Mask"
BPK_VIEWPORT_OUTLINE_COMPOSITE_NODE_NAME = "BPK Viewport Outline Composite"

OUTLINE_NODE_NAMES = (
    BPK_OUTLINE_GROUP_NODE_NAME,
    BPK_OUTLINE_DILATE_NODE_NAME,
    BPK_OUTLINE_MASK_NODE_NAME,
    BPK_OUTLINE_COMPOSITE_NODE_NAME,
    BPK_VIEWPORT_OUTLINE_DILATE_NODE_NAME,
    BPK_VIEWPORT_OUTLINE_MASK_NODE_NAME,
    BPK_VIEWPORT_OUTLINE_COMPOSITE_NODE_NAME,
)


def get_viewport_outline_thickness(render_thickness, preview_resolution):
    if render_thickness <= 0:
        return 0

    safe_preview_resolution = max(0.001, preview_resolution)

    return max(1, round(render_thickness / safe_preview_resolution))


def apply_outline_settings_to_tree(
    node_tree,
    outline_thickness,
    outline_color,
    background_color,
    preview_resolution,
):
    outline_group_node = node_tree.nodes.get(BPK_OUTLINE_GROUP_NODE_NAME)

    if outline_group_node is None or outline_group_node.node_tree is None:
        return False

    outline_group = outline_group_node.node_tree
    outline_nodes = (
        (
            BPK_OUTLINE_DILATE_NODE_NAME,
            BPK_OUTLINE_MASK_NODE_NAME,
            outline_thickness,
        ),
        (
            BPK_VIEWPORT_OUTLINE_DILATE_NODE_NAME,
            BPK_VIEWPORT_OUTLINE_MASK_NODE_NAME,
            get_viewport_outline_thickness(
                outline_thickness,
                preview_resolution,
            ),
        ),
    )

    for dilate_node_name, mask_node_name, node_outline_thickness in outline_nodes:
        dilate_node = outline_group.nodes.get(dilate_node_name)
        mask_node = outline_group.nodes.get(mask_node_name)

        if dilate_node is not None:
            size_socket = dilate_node.inputs.get("Size")

            if size_socket is not None:
                size_socket.default_value = node_outline_thickness

        if mask_node is not None:
            background_socket = mask_node.inputs.get("Background")
            foreground_socket = mask_node.inputs.get("Foreground")

            if background_socket is not None:
                background_socket.default_value = background_color

            if foreground_socket is not None:
                foreground_socket.default_value = outline_color

    return True
