import bpy


VIEWPORT_PIXEL_GROUP_NAME = "BPK Viewport Pixel"
VIEWPORT_PIXEL_GROUP_NODE_NAME = "BPK Viewport Pixel"
VIEWPORT_PIXEL_VIEWER_NODE_NAME = "BPK Viewport Pixel Viewer"
VIEWPORT_PIXEL_VALUE_NODE_NAME = "BPK Viewport Pixel Value"
VIEWPORT_PIXEL_DOWNSCALE_NODE_NAME = "BPK Pixel Preview Downscale"
VIEWPORT_PIXEL_UPSCALE_NODE_NAME = "BPK Pixel Preview Upscale"


def get_scene_compositor_tree(scene, create=False):
    if hasattr(scene, "compositing_node_group"):
        node_tree = scene.compositing_node_group

        if node_tree is None and create:
            node_tree = bpy.data.node_groups.new(
                name="BPK Compositor Nodes",
                type="CompositorNodeTree",
            )
            scene.compositing_node_group = node_tree

        return node_tree

    if create:
        scene.use_nodes = True

    return getattr(scene, "node_tree", None)


def set_viewport_pixel_value(scene, value):
    node_tree = get_scene_compositor_tree(scene)

    if node_tree is None:
        return False

    group = _get_viewport_pixel_group(node_tree)

    if group is None:
        return False

    value_node = group.nodes.get(VIEWPORT_PIXEL_VALUE_NODE_NAME)

    if value_node is None:
        return False

    value_node.outputs[0].default_value = value
    return True


def set_viewport_pixel_transform(scene, value, offset_x, offset_y):
    node_tree = get_scene_compositor_tree(scene)

    if node_tree is None:
        return False

    group = _get_viewport_pixel_group(node_tree)

    if group is None:
        return False

    value_node = group.nodes.get(VIEWPORT_PIXEL_VALUE_NODE_NAME)
    downscale_node = group.nodes.get(VIEWPORT_PIXEL_DOWNSCALE_NODE_NAME)
    upscale_node = group.nodes.get(VIEWPORT_PIXEL_UPSCALE_NODE_NAME)

    if value_node is None or downscale_node is None or upscale_node is None:
        return False

    value_node.outputs[0].default_value = value
    _set_node_input_default(downscale_node, "X", -offset_x)
    _set_node_input_default(downscale_node, "Y", -offset_y)
    _set_node_input_default(upscale_node, "X", offset_x)
    _set_node_input_default(upscale_node, "Y", offset_y)

    return True


def _set_node_input_default(node, input_name, value):
    socket = node.inputs.get(input_name)

    if socket is None or not hasattr(socket, "default_value"):
        return

    socket.default_value = value


def _get_viewport_pixel_group(scene_node_tree):
    group_node = scene_node_tree.nodes.get(VIEWPORT_PIXEL_GROUP_NODE_NAME)

    if group_node is None:
        return None

    return group_node.node_tree
