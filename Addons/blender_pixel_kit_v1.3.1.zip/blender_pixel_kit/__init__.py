bl_info = {
    "name": "Blender Pixel Kit",
    "author": "SouthernShotty",
    "version": (1, 2, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Pixel Kit",
    "description": "Lightweight pixel-art workflow setup tools for Blender.",
    "category": "3D View",
}

import sys


if not __package__:
    raise ImportError(
        "Blender Pixel Kit must be installed as the blender_pixel_kit package. "
        "Install blender_pixel_kit.zip through Blender Preferences > Add-ons."
    )


for module_name in list(sys.modules):
    if module_name.startswith(__name__ + "."):
        del sys.modules[module_name]

from .operators import camera_tools
from .operators import materials
from .operators import outline
from .operators import render_settings
from .operators import viewport_preview
from .properties import settings
from .ui import panel


modules = (
    settings,
    render_settings,
    camera_tools,
    materials,
    outline,
    viewport_preview,
    panel,
)


def register():
    for module in modules:
        module.register()


def unregister():
    for module in reversed(modules):
        module.unregister()
