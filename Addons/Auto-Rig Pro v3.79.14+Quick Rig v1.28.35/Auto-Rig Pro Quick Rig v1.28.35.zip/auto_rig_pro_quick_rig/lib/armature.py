import bpy
from .version_arm_collec import *


def get_arm_col_idx(armature, name):
    for i, coll in enumerate(get_armature_collections(armature)):          
        if coll.name == name:
            return i
            
'''
def sort_armature_collections(armature, only_collection=None):
    order = {'Main':0, 'Secondary':1, 'Orphan Bones':2, 'Deform':3, 'Reference':4}
        
    for col_name in order:
        if only_collection:
            if only_collection != col_name:
                continue
                
        col = armature.data.collections.get(col_name)  
        cur_idx = get_arm_col_idx(armature, col_name)
        to_idx = order[col_name]       
        armature.data.collections.move(cur_idx, to_idx)
'''        
        
def sort_armature_collections(armature, only_collection=None):
    order = {'Main':0, 'Secondary':1, 'Orphan Bones':2, 'Deform':3, 'Reference':4}
      
    # sort collections as defined in the "order" dict
    for col_name in order:
        if only_collection:
            if only_collection != col_name:
                continue
                
        
        cur_idx = get_arm_col_idx(armature, col_name)
        to_idx = order[col_name]
        
        # check if collection is parented, if so, offset the index from the first sibling
        col = get_armature_collections(armature).get(col_name)
        if col.parent:
            #print('Collection is parented:', col_name, 'get the first sibling index...')
            first_idx = 1000000
            for _c in get_armature_collections(armature):
                if _c.parent == col.parent and _c.index < first_idx:
                    first_idx = _c.index
            #print('First sibling is:', first_idx)
            to_idx += first_idx
            
        #print('Move from', cur_idx, 'to', to_idx)
        armature.data.collections.move(cur_idx, to_idx)
        

def is_bone_in_layer(bone_name, layer_type, idx=None):
    if bpy.app.version >= (4,0,0):
        if bpy.context.mode == 'EDIT_ARMATURE':# # in Edit mode, access edit bones only. Prone to error otherwise (bone data not up to date)
            in_collection = [ebone.name for ebone in bpy.context.active_object.data.edit_bones if layer_type in ebone.collections]
            return bone_name in in_collection
        else:
            return layer_type in bpy.context.active_object.data.bones.get(bone_name).collections
    else:      
        if bpy.context.mode == 'EDIT_ARMATURE':# in Edit mode, access edit bones only. Prone to error otherwise (bone data not up to date)
            return bpy.context.active_object.data.edit_bones.get(bone_name).layers[idx]
        else:
            return bpy.context.active_object.data.bones.get(bone_name).layers[idx]


def enable_layer(layer_type, idx=None):
    if bpy.app.version >= (4,0,0):
        col = get_armature_collections(bpy.context.active_object).get(layer_type)
        col.is_visible = True
    else:
        bpy.context.active_object.data.layers[idx] = True
        
        
def hide_layer(layer_type, idx=None):
    if bpy.app.version >= (4,0,0):
        col = bpy.context.active_object.data.collections.get(layer_type)
        col.is_visible = False
    else:     
        bpy.context.active_object.data.layers[idx] = False


def set_bone_layer(bone, layer_type, idx=None, multi=False):
    if bpy.app.version >= (4,0,0):
        arma = bpy.context.active_object
        col = arma.data.collections.get(layer_type)
        if col == None:# create the collection if necessary
            col = arma.data.collections.new(layer_type)
            col.is_visible = False
            
        if bpy.context.mode == 'EDIT_ARMATURE':
            col.assign(bone)
        else:
            col.assign(arma.data.bones[bone.name])
        
        if multi:
            return
            
        for col in arma.data.collections:
            if col.name != layer_type:
                if bpy.context.mode == 'EDIT_ARMATURE':
                    col.unassign(bone)
                else:
                    col.unassign(arma.data.bones[bone.name])
        
    else:
        bone.layers[idx] = True
        
        if multi:
            return
            
        for i, lay in enumerate(bone.layers):
            if i != idx:
                bone.layers[i] = False