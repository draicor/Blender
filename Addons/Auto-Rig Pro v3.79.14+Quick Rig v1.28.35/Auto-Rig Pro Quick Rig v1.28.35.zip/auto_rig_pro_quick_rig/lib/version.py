import bpy
import addon_utils
from bpy_extras import anim_utils

class ARP_blender_version:
    _string = bpy.app.version_string
    blender_v = bpy.app.version
    _float = blender_v[0]*100+blender_v[1]+blender_v[2]*0.01
    
blender_version = ARP_blender_version()


def get_quickrig_version():
    #addons = addon_utils.modules()[:]
    
    addons = None
    if bpy.app.version >= (4,2,0):
        addons = addon_utils.modules()
    else:
        addons = addon_utils.modules()[:]
    
    for addon in addons:    
        if addon.bl_info['name'].startswith('Auto-Rig Pro: Quick Rig'):
            print(addon)
            ver_list = addon.bl_info.get('version')
            ver_string = str(ver_list[0]) + str(ver_list[1]) + str(ver_list[2])
            ver_int = int(ver_string)
            return ver_int
            

def ver_int_to_str(version_int):
    to_str = str(version_int)
    return to_str[0] + '.' + to_str[1] + to_str[2] + '.' + to_str[3] + to_str[4]
    
    
def get_prefs():
    if bpy.app.version >= (4,2,0):
        return bpy.context.preferences.addons[__package__[:-4]].preferences
    else:
        return bpy.context.preferences.addons[__package__.split('.')[0]].preferences
        
        
def delete_fcurve(act, fc, slot_idx=0):
    if bpy.app.version >= (5,0,0):
        cb = anim_utils.action_ensure_channelbag_for_slot(act, act.slots[slot_idx])
        cb.fcurves.remove(fc)
    else:
        act.fcurves.remove(fc)
        
        
def create_fcurve(act, dp, slot_idx=0, fc_index=0, action_group=''):
    if bpy.app.version >= (5,0,0):        
        if len(act.slots) == 0:# buggy action, no slots
            print("Warning, this action has not slots, cannot create fcurve:", act.name)
            return None
        
        cb = anim_utils.action_ensure_channelbag_for_slot(act, act.slots[slot_idx])
        return cb.fcurves.new(dp, index=fc_index, group_name=action_group)
        
    else:
        return act.fcurves.new(dp, index=fc_index, action_group=action_group)
        
        
def find_fcurve(act, dp, slot_idx=0, fc_index=0):
    if bpy.app.version >= (5,0,0):    
        if len(act.slots) == 0:# buggy action, no slots
            print("Warning, this action has not slots, skipped:", act.name)
            return None
            
        cb = anim_utils.action_get_channelbag_for_slot(act, act.slots[slot_idx])
        if cb == None: return None
        return cb.fcurves.find(dp, index=fc_index)
    else:
        return act.fcurves.find(data_path=dp, index=fc_index)
        
        
def get_action_fcurves(act, slot_idx=0, as_list=True):
    if bpy.app.version >= (5,0,0):    
        if len(act.slots) == 0:# buggy action, no slots
            print("Warning, this action has not slots, skipped:", act.name)
            return []
            
        cb = anim_utils.action_ensure_channelbag_for_slot(act, act.slots[slot_idx])

        if cb:
            if as_list:
                return [_fc for _fc in cb.fcurves if _fc != None]# check for None curve, debug
            else:
                return cb.fcurves
        else:
            print("No fcurves found in this slot:", slot_idx)
            return []
    else:
        return act.fcurves