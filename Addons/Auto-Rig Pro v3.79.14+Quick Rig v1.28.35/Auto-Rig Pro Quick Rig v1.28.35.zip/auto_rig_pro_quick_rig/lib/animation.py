import bpy, sys, math
from .maths_geo import *


def create_action(actionname):
    new_act = bpy.data.actions.new(actionname)
    if bpy.app.version >= (5,0,0):
        slot = new_act.slots.new('OBJECT', 'Slot 1')
        actlay = new_act.layers.new('Layer')
        actlay.strips.new(type='KEYFRAME')
    return new_act


def assign_armature_action(armature, _action, _slot_idx=0):
    if armature.animation_data:
        armature.animation_data.action = _action
        if bpy.app.version >= (4,4,0) and _action != None:
            if len(_action.slots):# debug old files compatibility
                armature.animation_data.action_slot = _action.slots[_slot_idx]


def get_action_slot_idx(act, act_slot):
    for sloti, slot in enumerate(act.slots):
        if slot == act_slot:
            return sloti
    return 0# safety
            
            
def get_action_slot_name(act, act_slot_idx):
    for sloti, slot in enumerate(act.slots):
        if sloti == act_slot_idx:
            return slot.name_display


def get_action_slot_frame_range(act, slot_idx):
    cb = act.layers[0].strips[0].channelbag(act.slots[slot_idx])
    min = float('inf')
    max = -min
    if cb:
        for fc in cb.fcurves:
            for kf in fc.keyframe_points:
                kf_x = kf.co[0]
                if kf_x < min:
                    min = kf_x
                if kf_x > max:
                    max = kf_x
    
    return min, max