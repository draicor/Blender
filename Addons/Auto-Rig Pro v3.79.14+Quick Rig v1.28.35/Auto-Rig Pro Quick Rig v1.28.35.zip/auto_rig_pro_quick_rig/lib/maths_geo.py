import bpy
from math import *
from mathutils import *


def are_vec_identical(vec1, vec2, round_val):
    same = True
    for i, j in enumerate(vec1):
        if round(j, round_val) != round(vec2[i], round_val):
            same = False
            break
            
    return same
    

def get_short_angle(vec1, vec2):
    # return the angle between two vectors, regardless of their directions (as lines)
    vec1 = vec1.normalized()
    vec2 = vec2.normalized()
    _a = vec1.angle(vec2)
    if _a > pi/2:
        _a = (-vec1).angle(vec2)
    return _a
    

def signed_angle(vector_u, vector_v, normal):
    normal = normal.normalized()
    a = vector_u.angle(vector_v)
    
    if not vector_u.cross(vector_v).magnitude == 0:# parallel
        if vector_u.cross(vector_v).angle(normal) < 1:
            a = -a
    return a
    
    
def rotate_vec_mat(vec, angle, pivot, axis):
    # rotate a vector around given pivot point,
    # angle and axis
    mat_rot = Matrix.Rotation(-angle, 4, axis)
    mat_to_center = Matrix.Translation(-pivot).to_4x4()
    return mat_to_center.inverted() @ mat_rot @ mat_to_center @ vec      
    
    
def project_point_onto_plane(q, p, n):
    # q = point
    # p = point belonging to the plane
    # n = plane normal
    n = n.normalized()
    return q - ((q - p).dot(n)) * n
    
    
def project_vec_onto_plane(x, n):
    # x: Vector
    # n: plane normal vector
    d = x.dot(n) / n.magnitude
    p = [d * n.normalized()[i] for i in range(len(n))]
    return Vector([x[i] - p[i] for i in range(len(x))])
    
    
def project_point_onto_line(a, b, p):
    # project the point p onto the line a,b
    ap = p - a
    ab = b - a
    result_pos = a + ap.dot(ab) / ab.dot(ab) * ab
    return result_pos
    
    
def mat3_to_vec_roll(mat):
    vec = mat.col[1]
    vecmat = vec_roll_to_mat3(mat.col[1], 0)
    vecmatinv = vecmat.inverted()
    rollmat = vecmatinv @ mat
    roll = math.atan2(rollmat[0][2], rollmat[2][2])
    return vec, roll
    
    
def vec_roll_to_mat3(vec, roll):
    target = Vector((0, 0.1, 0))
    nor = vec.normalized()
    axis = target.cross(nor)
    if axis.dot(axis) > 0.0000000001: # this seems to be the problem for some bones, no idea how to fix
        axis.normalize()
        theta = target.angle(nor)
        bMatrix = Matrix.Rotation(theta, 3, axis)
    else:
        updown = 1 if target.dot(nor) > 0 else -1
        bMatrix = Matrix.Scale(updown, 3)
        bMatrix[2][2] = 1.0

    rMatrix = Matrix.Rotation(roll, 3, nor)
    mat = rMatrix @ bMatrix
    return mat
    
    
def rotate_point(point_loc, angle, axis, origin):
    # rotate the point_loc (vector 3) around the "axis" (vector 3) 
    # for the angle value (radians)
    # around the origin (vector 3)
    rot_mat = Matrix.Rotation(angle, 4, axis.normalized())
    loc = point_loc.copy()
    loc = loc - origin
    point_mat = Matrix.Translation(loc).to_4x4()
    point_mat_rotated = rot_mat @ point_mat
    loc, rot, scale = point_mat_rotated.decompose()
    loc = loc + origin
    return loc