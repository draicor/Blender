import bpy, os
from .bone_edit import *
from .context import *


def is_object_hidden(obj_to_get):
    if obj_to_get.hide_get() == False and obj_to_get.hide_viewport == False:
        return False
    else:
        return True
        
        
def duplicate_object(new_name='', method='operator', obj=None):
    if method == 'operator':            
        try:
            bpy.ops.object.duplicate(linked=False, mode='TRANSLATION')
        except:
            bpy.ops.object.duplicate('TRANSLATION', False)
        if new_name != '':
            bpy.context.active_object.name = new_name
            
    elif method == 'data':        
        if obj:
            # copy object
            _obj_dupli = obj.copy()
            # copy collections            
            for col in obj.users_collection:
                try: col.objects.link(_obj_dupli)
                except: bpy.context.collection.objects.link(_obj_dupli)# overridden/locked collection, link to active scene collection instead
            # copy object data
            _obj_dupli.data = _obj_dupli.data.copy()
            # set name
            if new_name != '':
                _obj_dupli.name = new_name
                
            return _obj_dupli
            
        else:        
            print('Cannot duplicate object, not found')           
            
    elif method == 'raw':
        if obj:
            new_mesh = bpy.data.meshes.new(new_name)
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            _obj_dupli = bpy.data.objects.new(new_name, new_mesh)
            bm.to_mesh(new_mesh)
            bm.free()
            for col in obj.users_collection:
                col.objects.link(_obj_dupli)
            new_mesh.update()
            return _obj_dupli
        

def get_object(name, view_layer_change=False):
    ob = bpy.data.objects.get(name)
    if ob:
        if view_layer_change:
            found = False
            for v_o in bpy.context.view_layer.objects:
                if v_o == ob:
                    found = True
            if not found:# object not in view layer, add to the base collection
                bpy.context.collection.objects.link(ob)

    return ob


def delete_object(obj):
    bpy.data.objects.remove(obj, do_unlink=True)


def set_active_object(object_name):
     bpy.context.view_layer.objects.active = bpy.data.objects[object_name]
     bpy.data.objects[object_name].select_set(state=True)